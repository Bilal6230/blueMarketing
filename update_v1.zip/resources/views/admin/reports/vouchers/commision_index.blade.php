@extends('admin.layouts.master')

@section('content')
    <div class="content-wrapper">
        <div class="content">
            <div class="container-fluid mt-1">
                <div class="card shadow-lg border-0">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">{{ $title }}</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <a href="{{ route('commision.voucher.create') }}" class="btn btn-success">
                                <i class="fas fa-plus"></i> Add New Voucher
                            </a>
                        </div>

                        <!-- Filter Section -->
                        <div id="filtersSection" class="row mb-3" >
                            <!-- Voucher Number -->
                            <div class="col-md-3">
                                <label for="filter_voucher_number">Voucher Number</label>
                                <input type="text" id="filter_voucher_number" class="form-control"
                                    placeholder="Voucher Number">
                            </div>

                            <!-- Date -->
                            <div class="col-md-3">
                                <label for="filter_date">Date</label>
                                <input type="text" id="filter_date" class="form-control date" placeholder="YYYY-MM-DD">
                            </div>

                            <!-- Amount -->
                            <div class="col-md-3">
                                <label for="filter_amount">Amount</label>
                                <input type="number" id="filter_amount" class="form-control" placeholder="Amount">
                            </div>

                            <!-- Reference -->
                            <div class="col-md-3">
                                <label for="filter_reference">Reference</label>
                                <input type="text" id="filter_reference" class="form-control" placeholder="Reference">
                            </div>

                            <div class="col-md-3 mt-4">
                                <button id="applyFilters" class="btn btn-primary btn-sm">Apply Filters</button>
                                <button id="resetFilters" class="btn btn-secondary btn-sm">Reset</button>
                            </div>
                        </div>

                        <!-- Table -->
                        <table id="journalTable" class="table table-bordered">
                            <thead class="bg-primary text-white">
                                <tr>
                                    <th style="background-color: black !important">ID</th>
                                    <th style="background-color: black !important">Voucher Number</th>
                                    <th style="background-color: black !important">Reference</th>
                                    <th style="background-color: black !important">Date</th>
                                    <th style="background-color: black !important">Description</th>
                                    <th style="background-color: black !important">Amount</th>
                                    @canany(['edit jv', 'delete jv'])
                                        <th style="background-color: black !important">Actions</th>
                                    @endcanany
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Data will be dynamically loaded by AJAX -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('modal')
    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this Commission Voucher?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <form id="deleteForm" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        let isDateChanged = false;

        $(document).ready(function() {
            // Initialize DataTable with default data
            renderDataTable();

            // Toggle filter section visibility
            $('#toggleFilters').on('click', function() {
                $('#filtersSection').toggle();
            });

            // Date filter: Track if the date is changed by the user
            const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
            $('#filter_date').val(today); // Default to today's date

            // When the user changes the date, mark it as changed
            $('#filter_date').on('change', function() {
                isDateChanged = true; // Date was changed by the user
                renderDataTable(); // Re-render table with updated filters
            });

            // Apply Filters (Voucher number, Amount, and Reference)
            $('#filter_voucher_number, #filter_amount, #filter_reference').on('change', function() {
                renderDataTable();
            });

            // Reset Filters
            $('#resetFilters').on('click', function() {
                $('#filter_voucher_number').val('');
                $('#filter_amount').val('');
                $('#filter_reference').val('');
                $('#filter_date').val(today); // Reset to today's date
                isDateChanged = false;
                renderDataTable();
            });
        });
        // Delete Button Click
        $(document).on('click', '.delete-btn', function() {
            const id = $(this).data('id');
            const deleteUrl = `{{ route('commision.voucher.delete', ':id') }}`.replace(':id', id);
            $('#deleteForm').attr('action', deleteUrl);
            $('#deleteModal').modal('show');
        });

        function renderDataTable() {
            const filter_voucher_number = $('#filter_voucher_number').val();
            const filter_amount = $('#filter_amount').val();
            const filter_reference = $('#filter_reference').val();
            const filter_date = $('#filter_date').val();

            // Destroy existing DataTable if it exists
            $('#journalTable').DataTable().destroy();

            // Initialize DataTable with AJAX
            $('#journalTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: '{{ route('commision.voucher.index') }}', // Route to get data
                    type: 'GET',
                    data: function(d) {
                        d.filter_voucher_number = filter_voucher_number;
                        d.filter_amount = filter_amount;
                        d.filter_reference = filter_reference;
                        if (isDateChanged) {
                            d.filter_date = filter_date; // Send date filter if it has changed
                        }
                    },
                    dataSrc: 'data'
                },
                columns: [{
                        data: 'id'
                    },
                    {
                        data: 'voucher_number'
                    },
                    {
                        data: 'reference'
                    },
                    {
                        data: 'date'
                    },
                    {
                        data: 'description'
                    },
                    {
                        data: 'total_debit'
                    },
                    {
                        data: 'actions'
                    } // Action column for edit, delete, and print
                ]
            });
        }
    </script>
@endsection
