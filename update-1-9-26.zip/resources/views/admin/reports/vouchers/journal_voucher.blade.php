@extends('admin.layouts.master')

@section('content')
    <div class="content-wrapper">
        <div class="content">
            <div class="container-fluid mt-1">
                <div class="card shadow-lg border-0">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">{{ $title }}</h4>
                    </div>
                    <div class="card-body">
                        <form id="journalForm" action="{{ route('journal.voucher.store') }}" method="POST">
                            @csrf
                            <!-- Voucher Details -->
                            <div class="row mb-4">
                                <div class="col-sm-4">
                                    <div class="input-group">
                                        <label class="fbox">Voucher No.</label>
                                        <div class="input-group">
                                            <input type="text" value="1" name="action" hidden />
                                            <input type="text" class="form-control " name="voucher_number"
                                                value="{{ $type }}-{{getLastJvId() + 1}}"
                                                autocomplete="off" readonly>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="input-group">
                                        <label class="fbox">Reference</label>
                                        <div class="input-group">
                                            <input type="text"
                                                class="form-control @error('reference') is-invalid @enderror"
                                                name="reference" value="{{ old('reference') }}" autocomplete="off">
                                            @error('reference')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="input-group">
                                        <label class="fbox">Date</label>
                                        <div class="input-group">
                                            <input type="text" name="date" class="date form-control" data-input>
                                            <input type="hidden" id="hiddenDate" name="hiddenDate">
                                            @error('date')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Description -->
                            <div class="row mb-4">
                                <div class="col-md-12">
                                    <label for="description" class="form-label"><strong>Description</strong></label>
                                    <textarea id="description" name="description" class="form-control" rows="3" required></textarea>
                                </div>
                            </div>

                            <!-- Dynamic Table for Journal Entries -->
                            <div class="table-responsive mb-4">
                           <table class="table table-bordered" id="journalTable" style="table-layout: fixed;">

    <colgroup>
        <col style="width: 15%">  <!-- Account (DECREASED) -->
        <col style="width: 15%">  <!-- Sub-Account (DECREASED) -->
        <col style="width: 35%">  <!-- Description (INCREASED) -->
        <col style="width: 10%">  <!-- Debit -->
        <col style="width: 10%">  <!-- Credit -->
        <col style="width: 15%">  <!-- Action -->
    </colgroup>

    <thead class="bg-primary text-white">
        <tr>
            <th style="background-color:black">Account</th>
            <th style="background-color:black">Sub-Account</th>
            <th style="background-color:black">Description</th>
            <th style="background-color:black">Debit (Out)</th>
            <th style="background-color:black">Credit (IN)</th>
            <th style="background-color:black">Action</th>
        </tr>
    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <select name="accounts[]" class="form-control select2 account-select"
                                                    required>
                                                    <option value="">Select Account</option>
                                                    @foreach ($accounts as $account)
                                                        <option value="{{ $account->head_accounting_id }}">
                                                            {{ $account->headAccounting->name }}</option>
                                                    @endforeach
                                                </select>
                                            </td>
                                            <td>
                                                <select name="sub_accounts[]"
                                                    class="form-control select2 sub-account-select" required>
                                                    <option value="">Select Sub-Account</option>
                                                </select>
                                            </td>
                                            <td><input type="text" name="line_description[]" class="form-control"></td>
                                            <td><input type="number" name="credit[]" class="form-control" step="0.01">
                                            </td>
                                            <td><input type="number" name="debit[]" class="form-control" step="0.01">
                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-success btn-sm add-row">
                                                    <i class="fas fa-plus"></i>
                                                </button>
                                                <button type="button" class="btn btn-danger btn-sm remove-row">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td colspan="3" class="text-end"><strong>Total:</strong></td>
                                            <td><input type="text" id="totalCredit" class="form-control" readonly></td>
                                            <td><input type="text" id="totalDebit" class="form-control" readonly></td>
                                            <td></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>

                            <!-- Submit Button -->
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Save Journal Voucher
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        $(document).ready(function() {
            // Add a new row to the table
            $(document).on('click', '.add-row', function() {
                const newRow = `
                <tr>
                    <td>
                        <select name="accounts[]" class="form-control select2 account-select" required>
                            <option value="">Select Account</option>
                            @foreach ($accounts as $account)
                                <option value="{{ $account->head_accounting_id }}">{{ $account->headAccounting->name }}</option>
                            @endforeach
                        </select>
                    </td>
                    <td>
                        <select name="sub_accounts[]" class="form-control select2 sub-account-select" required>
                            <option value="">Select Sub-Account</option>
                        </select>
                    </td>
                    <td><input type="text" name="line_description[]" class="form-control"></td>
                    <td><input type="number" name="credit[]" class="form-control" step="0.01"></td>
                    <td><input type="number" name="debit[]" class="form-control" step="0.01"></td>
                    <td>
                        <button type="button" class="btn btn-danger btn-sm remove-row">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>`;
                $('#journalTable tbody').append(newRow);
            });

            // Remove a row from the table
            $(document).on('click', '.remove-row', function() {
                $(this).closest('tr').remove();
                calculateTotals();
            });

            // Update Total Debit and Credit
            $(document).on('input', 'input[name="debit[]"], input[name="credit[]"]', function() {
                calculateTotals();
            });

            // Calculate Totals
            function calculateTotals() {
                let totalDebit = 0;
                let totalCredit = 0;

                $('input[name="debit[]"]').each(function() {
                    totalDebit += parseFloat($(this).val()) || 0;
                });
                $('input[name="credit[]"]').each(function() {
                    totalCredit += parseFloat($(this).val()) || 0;
                });

                $('#totalDebit').val(totalDebit.toFixed(2));
                $('#totalCredit').val(totalCredit.toFixed(2));
            }

            // Trigger Submission Confirmation Modal
            $('#journalForm').on('submit', function(e) {
                e.preventDefault();
                const totalDebit = parseFloat($('#totalDebit').val()) || 0;
                const totalCredit = parseFloat($('#totalCredit').val()) || 0;

                if (totalDebit !== totalCredit) {
                    // Show Error Modal
                    $('#errorModal').modal('show');
                } else {
                    // Show Confirmation Modal
                    $('#confirmationModal').modal('show');
                }
            });

            // Confirm and Submit the Form
            $('#confirmSubmit').on('click', function() {
                $('#journalForm')[0].submit();
            });

            // Fetch Sub-Accounts dynamically via AJAX when account is selected
            $(document).on('change', '.account-select', function() {
                const accountID = $(this).val();
                const subAccountSelect = $(this).closest('tr').find('.sub-account-select');

                if (accountID) {
                    $.ajax({
                        url: '{{ route('get_account') }}',
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            projectID: {{ getSelectedTown() }}, // Replace with the dynamic project ID if applicable
                            accountID: accountID,
                            action: 'get_child',
                            _token: '{{ csrf_token() }}' // CSRF token for Laravel
                        },
                        success: function(response) {
                            // Clear and populate the sub-account dropdown
                            subAccountSelect.empty().append(
                                '<option value="">Select Sub-Account</option>');

                            if (response.length > 0) {
                                $.each(response, function(index, item) {
                                    if (item.subhead_accounting) {
                                        subAccountSelect.append('<option value="' + item
                                            .id + '">' + item.subhead_accounting
                                            .name + '</option>');
                                    }
                                });
                            } else {
                                alert('No sub-accounts found for the selected account.');
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('Error: ' + error);
                        }
                    });
                } else {
                    // Reset the sub-account dropdown if no account is selected
                    subAccountSelect.empty().append('<option value="">Select Sub-Account</option>');
                }
            });

        });
    </script>
@endsection



@section('modal')
    <div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="errorModalLabel">Validation Error</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Total Debit and Credit must be equal. Please review your entries.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="confirmationModal" tabindex="-1" aria-labelledby="confirmationModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="confirmationModalLabel">Confirm Submission</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to submit this Journal Voucher?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirmSubmit">Yes, Submit</button>
                </div>
            </div>
        </div>
    </div>
@endsection
