<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($title); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create lead')): ?>
                                <div class="card-header">
                                    
                                    <div>
                                        <form action="<?php echo e(route('accounting.store')); ?>" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>

                                            <div class="row">
                                                <div class="col-sm-4">
                                                    <div class="input-group">
                                                        <label class="fbox">Projects</label>
                                                        <div class="input-group">
                                                            <select class="form-control" name="projects_id" id="projects_id">
                                                                <option value="">Select an option</option>

                                                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($v->id); ?>"><?php echo e($v->project); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php $__errorArgs = ['projects_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="input-group">
                                                        <label class="fbox">Accounts</label>
                                                        <div class="input-group">
                                                            <select class="form-control" name="accounts_id" id="accounts_id">
                                                                <option value="">Select an option</option>

                                                                
                                                            </select>
                                                            <?php $__errorArgs = ['accounts_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="input-group">
                                                        <label class="fbox">SubAccounts</label>
                                                        <div class="input-group">
                                                            <select class="form-control" name="subaccounts_id" id="subaccounts_id">
                                                                <option value="">Select an option</option>

                                                                
                                                            </select>
                                                            <?php $__errorArgs = ['subaccounts_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-3">
                                                    <div class="input-group">
                                                        <label class="fbox">Price</label>
                                                        <div class="input-group">
                                                            <input type="text" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Price" name="price" value="<?php echo e(old('price')); ?>">
                                                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-3">
                                                    <div class="input-group">
                                                        <label class="fbox">Detail</label>
                                                        <div class="input-group">
                                                            <input type="text" class="form-control <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Detail" name="detail" value="<?php echo e(old('detail')); ?>">
                                                            <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-3">
                                                    <div class="icheck-primary">
                                                        <input class="form-check-input" type="checkbox" name="cash_in" id="cash_in">
                                                        <label class="form-check-label" for="cash_in">
                                                            Cash In
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-sm-3">
                                                    <div class="modal-footer justify-content-between">
                                                        <button type="submit" class="btn btn-primary">Save</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Head Account</th>
                                            <th>Sub Head Account</th>
                                            <th>Price</th>
                                            <th>Detail</th>
                                            <th>Project</th>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['update lead'])): ?>
                                                <th>Action</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td>
                                                    <?php echo e($i->projectHeadSubhead->headAccounting->name ?? ''); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($i->projectHeadSubhead->subheadAccounting->name ?? ''); ?>


                                                </td>
                                                <td>
                                                    <?php echo e($i->price); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($i->detail); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($i->projectHeadSubhead->project->project ?? ''); ?>

                                                </td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['update lead', 'delete lead'])): ?>
                                                    <td>
                                                        <div class="btn-group">
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update lead')): ?>
                                                                <button class="btn btn-sm btn-primary btn-edit" data-id="<?php echo e($i->id); ?>"><i class="fas fa-pencil-alt"></i></button>
                                                            <?php endif; ?>
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete lead')): ?>
                                                                <button class="btn btn-sm btn-danger btn-delete" data-id="<?php echo e($i->id); ?>" data-name="<?php echo e($i->name); ?>"><i class="fas fa-trash"></i></button>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->


                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>












        $(document).ready(function() {


            $('#projects_id').change(function () {
                var projectID = $(this).val();

                console.log(projectID);
                if (projectID) {
                    $.ajax({
                        url: '<?php echo e(route('get_accounts_by_project')); ?>', // Replace with your actual route
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            projectID: projectID,
                            _token: '<?php echo e(csrf_token()); ?>' // Include CSRF token for Laravel
                        },
                        success: function (data) {
                            $('#accounts_id').empty();
                            $('#subaccounts_id').empty();
                            console.log(data);
                            // Filter data to match selected project ID
                            var filteredData = data.filter(function(item) {
                                return item.project_id == projectID;
                            });

                            // Append filtered head accounting options to 'Accounts' dropdown
                            $('#accounts_id').append('<option value="">Select an option</option>');
                            $.each(filteredData, function(key, value) {
                                $('#accounts_id').append('<option value="' + value.head_accounting_id + '">' + value.head_accounting.name + '</option>');
                            });

                            // You may implement a similar AJAX call to fetch subheadaccounts based on the selected account
                        }
                    });
                } else {
                    $('#accounts_id').empty();
                    $('#subaccounts_id').empty();
                }
            });

            // Similar change event for 'accounts_id' dropdown to fetch subaccounts based on account selection
            $('#accounts_id').change(function () {
                var accountID = $(this).val();
                var projectID = $('#projects_id').val();


                if (accountID) {
                    // Implement AJAX call to fetch subheadaccounts based on the selected account
                    $.ajax({
                        url: '<?php echo e(route('get_subaccounts_by_project')); ?>', // Replace with your actual route
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            accountID: accountID,
                            projectID: projectID,

                            _token: '<?php echo e(csrf_token()); ?>' // Include CSRF token for Laravel
                        },
                        success: function (data) {
                            $('#subaccounts_id').empty();
                            console.log(data);
                            // Filter data to match selected project ID
                            var filteredData = data.filter(function(item) {
                                return item.head_accounting_id  == accountID;
                            });
                            $('#subaccounts_id').append('<option value="">Select an option</option>');

                            // Append filtered head accounting options to 'Accounts' dropdown
                            $.each(filteredData, function(key, value) {
                                $('#subaccounts_id').append('<option value="' + value.subhead_accounting_id + '">' + value.subhead_accounting.name + '</option>');
                            });

                            // You may implement a similar AJAX call to fetch subheadaccounts based on the selected account
                        }
                    });
                } else {
                    $('#subaccounts_id').empty();
                }
            });
            $('#edit_projects_id').change(function () {
                var projectID = $(this).val();

                console.log(projectID);
                if (projectID) {
                    $.ajax({
                        url: '<?php echo e(route('get_accounts_by_project')); ?>', // Replace with your actual route
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            projectID: projectID,
                            _token: '<?php echo e(csrf_token()); ?>' // Include CSRF token for Laravel
                        },
                        success: function (data) {
                            $('#edit_accounts_id').empty();
                            $('#edit_subaccounts_id').empty();
                            console.log(data);
                            // Filter data to match selected project ID
                            var filteredData = data.filter(function(item) {
                                return item.project_id == projectID;
                            });

                            // Append filtered head accounting options to 'Accounts' dropdown
                            $('#edit_accounts_id').append('<option value="">Select an option</option>');
                            $.each(filteredData, function(key, value) {
                                $('#edit_accounts_id').append('<option value="' + value.head_accounting_id + '">' + value.head_accounting.name + '</option>');
                            });

                            // You may implement a similar AJAX call to fetch subheadaccounts based on the selected account
                        }
                    });
                } else {
                    $('#edit_accounts_id').empty();
                    $('#edit_subaccounts_id').empty();
                }
            });
            $('#edit_accounts_id').change(function () {
                var accountID = $(this).val();
                var projectID = $('#edit_projects_id').val();


                if (accountID) {
                    // Implement AJAX call to fetch subheadaccounts based on the selected account
                    $.ajax({
                        url: '<?php echo e(route('get_subaccounts_by_project')); ?>', // Replace with your actual route
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            accountID: accountID,
                            projectID: projectID,

                            _token: '<?php echo e(csrf_token()); ?>' // Include CSRF token for Laravel
                        },
                        success: function (data) {
                            $('#edit_subaccounts_id').empty();
                            console.log(data);
                            // Filter data to match selected project ID
                            var filteredData = data.filter(function(item) {
                                return item.head_accounting_id  == accountID;
                            });
                            $('#edit_subaccounts_id').append('<option value="">Select an option</option>');

                            // Append filtered head accounting options to 'Accounts' dropdown
                            $.each(filteredData, function(key, value) {
                                $('#edit_subaccounts_id').append('<option value="' + value.subhead_accounting_id + '">' + value.subhead_accounting.name + '</option>');
                            });

                            // You may implement a similar AJAX call to fetch subheadaccounts based on the selected account
                        }
                    });
                } else {
                    $('#edit_subaccounts_id').empty();
                }
            });








            $(document).on("click", '.btn-edit', function() {
                let id = $(this).attr("data-id");
                $('#modal-loading').modal({backdrop: 'static', keyboard: false, show: true});
                $.ajax({
                    url: "<?php echo e(route('accounting.show')); ?>",
                    type: "POST",
                    dataType: "JSON",
                    data: {
                        id: id,
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(data) {
                        console.log(data);
                        var data = data.data;
                        $("#id").val(data.id);
                        console.log(data.id);
                        $("#price").val(data.price);
                        console.log(data.price);
                        if (data.cash_in === 1) {
                            $("#edit_cash_in").prop("checked", true);
                        } else {
                            $("#edit_cash_in").prop("checked", false);
                        }
                        // $("#edit_cash_in").val(data.cash_in);
                        // console.log(data.cash_in);
                        $("#detail").val(data.detail);
                        console.log(data.detail);
                        // if (data.project_head_subhead) {
                        //     // Project
                        //     if (data.project_head_subhead.project && data.project_head_subhead.project.id) {
                        //         $("#edit_projects_id").val(data.project_head_subhead.project.id);
                        //         console.log(data.project_head_subhead.project.id);
                        //     }

                        //     // Head Accounting
                        //     if (data.project_head_subhead.head_accounting && data.project_head_subhead.head_accounting.id) {
                        //         $("#edit_accounts_id").val(data.project_head_subhead.head_accounting.id);
                        //         console.log(data.project_head_subhead.head_accounting.id);
                        //     }

                        //     // Subhead Accounting
                        //     if (data.project_head_subhead.subhead_accounting && data.project_head_subhead.subhead_accounting.id) {
                        //         $("#edit_subaccounts_id").val(data.project_head_subhead.subhead_accounting.id);
                        //         console.log(data.project_head_subhead.subhead_accounting.id);
                        //     }
                        // }

                        $('#modal-loading').modal('hide');
                        $('#modal-edit').modal({backdrop: 'static', keyboard: false, show: true});
                    },
                });
            });

            $(document).on("click", '.btn-delete', function() {
                let id = $(this).attr("data-id");
                let price = $(this).attr("data-price");
                $("#did").val(id);
                $("#delete-data").html(price);
                $('#modal-delete').modal({backdrop: 'static', keyboard: false, show: true});
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

    
    <div class="modal fade" id="modal-edit">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit User</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('accounting.update')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("PUT"); ?>
                        <div class="row">
                            <div class="col-sm-3">
                                <div class="input-group">
                                    <label class="fbox">Price</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Price" name="price" value="<?php echo e(old('price')); ?>" id="price">
                                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="icheck-primary">
                                    <input class="form-check-input" type="checkbox" name="edit_cash_in" id="edit_cash_in">
                                    <label class="form-check-label" for="edit_cash_in">
                                        Cash In
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-3">
                                <div class="input-group">
                                    <label class="fbox">Detail</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Detail" name="detail" value="<?php echo e(old('detail')); ?>" id="detail">
                                        <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="modal-footer justify-content-between">
                            <input type="hidden" name="id" id="id">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
    </div>
    
    <div class="modal fade" id="modal-delete">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Clear Data</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('accounting.destroy')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <p class="modal-text">Are you sure you want to delete? <b id="delete-data"></b></p>
                        <input type="hidden" name="id" id="did">
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-danger">Save</button>
                </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\crm\resources\views/admin/accounting/accounting_index.blade.php ENDPATH**/ ?>