<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('dashboard')); ?>" class="brand-link">
    <img src="<?php echo e(asset(Setting::getValue('app_logo'))); ?>" alt="<?php echo e(Setting::getName('app_name')); ?>" class="brand-image img-circle elevation-3" style="opacity: .8">
    <span class="brand-text font-weight-light"><?php echo e(Setting::getValue('app_short_name')); ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
            <img src="<?php echo e(asset('template/admin/dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
            <a href="#" class="d-block"><?php echo e(Auth::user()->name); ?> <small></small></a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column nav-child-indent" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active':''); ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>Dashboard</p>
                    </a>
                </li><?php $i = 1; ?>
                <?php $__currentLoopData = $modulemenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($menus['menu_count'] == 1): ?>
                        <?php $__currentLoopData = $menus['menus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($i == 1): ?>
                                <?php
                                    $perm[] = $menu['permission'];
                                ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any($perm)): ?>
                                    <li class="nav-header ml-2">MASTER DATA</li>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($menu['permission'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route($menu['route'])); ?>" class="nav-link <?php echo e(request()->routeIs($menu['route']) == strtolower($menu['name']) ? 'active':''); ?>">
                                        <i class="nav-icon <?php echo e($menu['icon']); ?>"></i>
                                        <p><?php echo e($menu['name']); ?></p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $modulemenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($menus['menu_count'] > 1): ?>
                        <?php $__currentLoopData = $menus['menus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(count($menus['menus']) > 1): ?>
                                <?php if($loop->iteration == 1): ?>
                                    <?php
                                        $perm[] = $menu['permission'];
                                    ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any($perm)): ?>
                                        <li class="nav-header ml-2"><?php echo e(strtoupper($menus['module'])); ?></li>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($menu['permission'])): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route($menu['route'])); ?>" class="nav-link <?php echo e(request()->routeIs($menu['route']) == strtolower($menu['name']) ? 'active':''); ?>">
                                            <i class="nav-icon <?php echo e($menu['icon']); ?>"></i>
                                            <p><?php echo e($menu['name']); ?></p>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read user', 'read role', 'read permission'])): ?>
                    <li class="nav-item">
                        <a href="#" class="nav-link <?php echo e(request()->routeIs('accounting*') ? 'active':''); ?>">
                            <i class="nav-icon fas fa-plus"></i>
                            <p>Accounting<i class="right fas fa-angle-left"></i></p>
                        </a>
                        <ul class="nav nav-treeview" style="display: <?php echo e(request()->routeIs('accounting*') ? 'block':'none'); ?>;">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read user')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('accounting.head_index')); ?>" class="nav-link <?php echo e(request()->routeIs('accounting.head_index') ? 'active':''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Main Account</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read user')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('accounting.subhead_index')); ?>" class="nav-link <?php echo e(request()->routeIs('accounting.subhead_index') ? 'active':''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Child Account</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read user')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('accounting.category_index')); ?>" class="nav-link <?php echo e(request()->routeIs('accounting.category_index') ? 'active':''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Joint Account</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                           
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read voucher'])): ?>
                    <li class="nav-item">
                        <a href="#" class="nav-link <?php echo e(request()->routeIs('finance.voucher*') ? 'active':''); ?>">
                            <i class="nav-icon fas fa-ticket-alt"></i>
                            <p>Vouchers<i class="right fas fa-angle-left"></i></p>
                        </a>
                        <ul class="nav nav-treeview" style="display: <?php echo e(request()->routeIs('finance.voucher*') ? 'block':'none'); ?>;">
                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read voucher')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('finance.voucher.in')); ?>" class="nav-link <?php echo e(request()->routeIs('finance.voucher.in') ? 'active':''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Cash In</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('finance.voucher.out')); ?>" class="nav-link <?php echo e(request()->routeIs('finance.voucher.out') ? 'active':''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Cash out</p>
                                    </a>
                                </li>
                                
                            <?php endif; ?>

                            
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['master report', 'project report', 'voucher report'])): ?>
                    <li class="nav-item">
                        <a href="#" class="nav-link <?php echo e(request()->routeIs('finance.reports*') ? 'active':''); ?>">
                            <i class="fas fa-print nav-icon"></i>
                            <p>Finance Reports<i class="right fas fa-angle-left"></i></p>
                        </a>
                        <ul class="nav nav-treeview" style="display: <?php echo e(request()->routeIs('finance.reports*') ? 'block':'none'); ?>;">
                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read user')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('finance.reports.details_index')); ?>" class="nav-link <?php echo e(request()->routeIs('finance.reports.details_index') ? 'active':''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Expense Report</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('master report')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('finance.reports.show_ledger')); ?>" class="nav-link <?php echo e(request()->routeIs('finance.reports.show_ledger') ? 'active':''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Ledger Report</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read lead'])): ?>
                    <li class="nav-item">
                        <a href="#" class="nav-link  <?php echo e(request()->routeIs('crm*') ? 'active':''); ?>">
                            <i class="nav-icon fas fa-hands-helping"></i>
                            <p>CRM<i class="right fas fa-angle-left"></i></p>
                        </a>
                        <ul class="nav nav-treeview" style="display: <?php echo e(request()->routeIs('crm*') ? 'block':'none'); ?>;">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read lead')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('crm.lead.index')); ?>" class="nav-link <?php echo e(request()->routeIs('crm.lead.index') ? 'active':''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>All Lead</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read lead')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('lead.work')); ?>" class="nav-link <?php echo e(request()->routeIs('lead.work') ? 'active':''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Start Work</p>
                                    </a>
                                </li>
                            <?php endif; ?>




                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read project', 'read sector' , 'read area'])): ?>
                    <li class="nav-item">
                        <a href="#" class="nav-link <?php echo e(request()->routeIs('project*','area*') ? 'active':''); ?>">
                            <i class="nav-icon fas fa-chart-pie"></i>
                            <p>Project Setup<i class="right fas fa-angle-left"></i></p>
                        </a>
                        <ul class="nav nav-treeview" style="display: <?php echo e(request()->routeIs('project*','area*') ? 'block':'none'); ?>;">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read project')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('project.index')); ?>" class="nav-link <?php echo e(request()->routeIs('project.index') ? 'active':''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Project List</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read sector')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('project.zone.index')); ?>" class="nav-link <?php echo e(request()->routeIs('project.zone.index') ? 'active':''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Sectors</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read area')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('area.index')); ?>" class="nav-link <?php echo e(request()->routeIs('area.index') ? 'active':''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Area</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read plot')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('project.plot.index')); ?>" class="nav-link <?php echo e(request()->routeIs('project.plot.index') ? 'active':''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Plots</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read user', 'read role', 'read permission'])): ?>
                    <li class="nav-item">
                        <a href="#" class="nav-link <?php echo e(request()->routeIs('user*') ? 'active':''); ?>">
                            <i class="fas fa-lock nav-icon"></i>
                            <p>Access<i class="right fas fa-angle-left"></i></p>
                        </a>
                        <ul class="nav nav-treeview" style="display: <?php echo e(request()->routeIs('user*') ? 'block':'none'); ?>;">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read user')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('user.index')); ?>" class="nav-link <?php echo e(request()->routeIs('user.index') ? 'active':''); ?>">
                                        <i class="fas fa-user nav-icon"></i>
                                        <p>User</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read role')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('role.index')); ?>" class="nav-link <?php echo e(request()->routeIs('role.index') ? 'active':''); ?>">
                                        <i class="fas fa-user-cog nav-icon"></i>
                                        <p>Role</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read permission')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('permission.index')); ?>" class="nav-link <?php echo e(request()->routeIs('permission.index') ? 'active':''); ?>">
                                        <i class="fas fa-unlock nav-icon"></i>
                                        <p>Permission</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read expence'])): ?>
                    <li class="nav-item">
                        <a href="#" class="nav-link  <?php echo e(request()->routeIs('expence*') ? 'active':''); ?>">
                            <i class="nav-icon fas fa-plus"></i>
                            <p>Expense<i class="right fas fa-angle-left"></i></p>
                        </a>
                        <ul class="nav nav-treeview" style="display: <?php echo e(request()->routeIs('expence*') ? 'block':'none'); ?>;">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read expence')): ?>
                                <li class="nav-item">
                                    <a href="#" class="nav-link ">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Expense Categories </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read expence')): ?>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Add Expense</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read expence')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('crm.lead.assign')); ?>" class="nav-link">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Today Expense Report</p>
                                </a>
                            </li>
                        <?php endif; ?>


                        </ul>
                    </li>
                <?php endif; ?>


                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read setting', 'filemanager'])): ?>
                    <li class="nav-item">
                        <a href="#" class="nav-link  <?php echo e(request()->routeIs('setting*') ? 'active':''); ?>">
                            <i class="nav-icon fas fa-wrench"></i>
                            <p>Setting<i class="right fas fa-angle-left"></i></p>
                        </a>
                        <ul class="nav nav-treeview" style="display: <?php echo e(request()->routeIs('setting*') ? 'block':'none'); ?>;">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read setting')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('setting.index')); ?>" class="nav-link <?php echo e(request()->routeIs('setting.index') ? 'active':''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Setting</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('filemanager')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('filemanager')); ?>" class="nav-link <?php echo e(request()->routeIs('filemanager') ? 'active':''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>File Manager</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['lead report'])): ?>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="nav-icon fas fa-paste"></i>
                            <p>Reports<i class="right fas fa-angle-left"></i></p>
                        </a>
                        <ul class="nav nav-treeview" style="display: ">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read lead')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('report.users')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Agent Report</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lead report')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('report.lead.index')); ?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>All Leads</p>
                                    </a>
                                </li>
                            <?php endif; ?>



                        </ul>
                    </li>
                <?php endif; ?>

                <li class="nav-header"></li>
                <li class="nav-item">
                <a href="#" class="nav-link bg-danger" data-toggle="modal" data-target="#modal-logout" data-backdrop="static" data-keyboard="false">
                    <i class="fas fa-sign-out-alt nav-icon"></i>
                    <p>Sign Out</p>
                </a>
                </li>
                <li class="nav-header"></li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\laragon\www\crm\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>