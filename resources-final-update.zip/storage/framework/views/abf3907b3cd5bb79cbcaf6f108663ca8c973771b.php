<footer class="main-footer text-sm">
    <strong>Copyright &copy; 2021-2022 <a href="https://adminlte.io">Waqas ERP (PH#0300-8682814)</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
    <b>Version</b> 3.2.0
    </div>
</footer>


<?php /**PATH /home/u541740294/domains/bluemarketing.com.pk/public_html/hr/resources/views/admin/layouts/footer.blade.php ENDPATH**/ ?>