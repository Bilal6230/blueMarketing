<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="content">
        <div class="container-fluid mt-1">
            <div class="card shadow-lg border-0">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h4 class="mb-0"><?php echo e($title); ?></h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <a href="<?php echo e(route('journal.voucher.create')); ?>" class="btn btn-success">
                            <i class="fas fa-plus"></i> Add New Voucher
                        </a>
                    </div>
                    <table id="journalTable" class="table table-bordered">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th>ID</th>
                                <th>Voucher Number</th>
                                <th>Reference</th>
                                <th>Date</th>
                                <th>Description</th>
                                <th>Amount</th>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit jv', 'delete jv'])): ?>
                                    <th>Actions</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($voucher->id); ?></td>
                                <td>JV-<?php echo e(get_jv_number($voucher->voucher_number)); ?></td>
                                <td><?php echo e($voucher->reference); ?></td>
                                <td><?php echo e($voucher->date); ?></td>
                                <td><?php echo e($voucher->description); ?></td>
                                <td><?php echo e($voucher->total_debit); ?></td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit jv', 'delete jv','print jv'])): ?>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit jv')): ?>
                                        <a href="<?php echo e(route('journal.voucher.edit', $voucher->id)); ?>" class="btn btn-sm btn-warning">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete jv')): ?>
                                        <button class="btn btn-sm btn-danger delete-btn" data-id="<?php echo e($voucher->id); ?>">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('print jv')): ?>
                                        <a href="<?php echo e(route('journal.voucher.print', $voucher->id)); ?>" target="_blank" class="btn btn-sm btn-info">
                                            <i class="fas fa-print"></i> Print
                                        </a>
                                        <?php endif; ?>

                                        

                                    </td>
                                <?php endif; ?>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this Journal Voucher?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form id="deleteForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
$(document).ready(function() {
    $('#journalTable').DataTable(); // Initialize DataTable

    // Delete Button Click
    $('.delete-btn').on('click', function () {
        const id = $(this).data('id');
        const deleteUrl = `<?php echo e(route('journal.voucher.delete', ':id')); ?>`.replace(':id', id);
        $('#deleteForm').attr('action', deleteUrl);
        $('#deleteModal').modal('show');
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u541740294/domains/bluemarketing.com.pk/public_html/hr/resources/views/admin/reports/vouchers/index.blade.php ENDPATH**/ ?>