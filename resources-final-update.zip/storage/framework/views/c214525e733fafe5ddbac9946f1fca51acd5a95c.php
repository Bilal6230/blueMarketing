

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content">
            <div class="container-fluid mt-1">
                <div class="card shadow-lg border-0">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <h4 class="mb-0"><?php echo e($title); ?></h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <a href="<?php echo e(route('journal.voucher.create')); ?>" class="btn btn-success">
                                <i class="fas fa-plus"></i> Add New Voucher
                            </a>
                        </div>

                        <!-- Filter Section -->
                        <div id="filtersSection" class="row mb-3">
                            <!-- Voucher Number -->
                            <div class="col-md-3">
                                <label for="filter_voucher_number">Voucher Number</label>
                                <input type="text" id="filter_voucher_number" class="form-control"
                                    placeholder="Voucher Number">
                            </div>

                            <!-- Date -->
                            <div class="col-md-3">
                                <label for="filter_date">Date</label>
                                <input type="text" id="filter_date" class="form-control date" placeholder="YYYY-MM-DD">
                            </div>

                            <!-- Amount -->
                            <div class="col-md-3">
                                <label for="filter_amount">Amount</label>
                                <input type="number" id="filter_amount" class="form-control" placeholder="Amount">
                            </div>

                            <!-- Reference -->
                            <div class="col-md-3">
                                <label for="filter_reference">Reference</label>
                                <input type="text" id="filter_reference" class="form-control" placeholder="Reference">
                            </div>

                            <div class="col-md-3 mt-4">
                                <button id="applyFilters" class="btn btn-primary btn-sm">Apply Filters</button>
                                <button id="resetFilters" class="btn btn-secondary btn-sm">Reset</button>
                            </div>
                        </div>

                        <!-- Table -->
                        <table id="journalTable" class="table table-bordered">
                            <thead class="bg-primary text-white">
                                <tr>
                                    <th style="background-color: black !important">ID</th>
                                    <th style="background-color: black !important">Voucher Number</th>
                                    <th style="background-color: black !important">Reference</th>
                                    <th style="background-color: black !important">Date</th>
                                    <th style="background-color: black !important">Description</th>
                                    <th style="background-color: black !important">Amount</th>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit jv', 'delete jv'])): ?>
                                        <th style="background-color: black !important">Actions</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($voucher->id); ?></td>
                                        <td>JV-<?php echo e(get_jv_number($voucher->voucher_number)); ?></td>
                                        <td><?php echo e($voucher->reference); ?></td>
                                        <td><?php echo e($voucher->date); ?></td>
                                        <td><?php echo e($voucher->description); ?></td>
                                        <td><?php echo e($voucher->total_debit); ?></td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit jv', 'delete jv', 'print jv'])): ?>
                                            <td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit jv')): ?>
                                                    <a href="<?php echo e(route('journal.voucher.edit', $voucher->id)); ?>"
                                                        class="btn btn-sm btn-warning">
                                                        <i class="fas fa-edit"></i> Edit
                                                    </a>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete jv')): ?>
                                                    <button class="btn btn-sm btn-danger delete-btn" data-id="<?php echo e($voucher->id); ?>">
                                                        <i class="fas fa-trash"></i> Delete
                                                    </button>
                                                <?php endif; ?>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('print jv')): ?>
                                                    <a href="<?php echo e(route('journal.voucher.print', $voucher->id)); ?>" target="_blank"
                                                        class="btn btn-sm btn-info">
                                                        <i class="fas fa-print"></i> Print
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this Journal Voucher?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <form id="deleteForm" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        let isDateChanged = false;
        $(document).ready(function() {
            // Toggle filter section visibility
            $('#toggleFilters').on('click', function() {
                $('#filtersSection').toggle();
            });

            // Apply Filters
            $('#applyFilters').on('click', function() {
                renderDataTable();
            });

            // Reset Filters
            $('#resetFilters').on('click', function() {
                $('#filter_voucher_number').val('');
                $('#filter_date').val('');
                $('#filter_amount').val('');
                $('#filter_reference').val('');
                renderDataTable();
            });

            // Date filter: Track if the date is changed by the user
            const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
            $('#filter_date').val(today); // Default to today's date

            // When the user changes the date, mark it as changed
            $('#filter_date').on('change', function() {
                isDateChanged = true; // Date was changed by the user
                renderDataTable(); // Re-render table with updated filters
            });

            // Apply Filters (Voucher number, Amount, and Reference)
            $('#filter_voucher_number, #filter_amount, #filter_reference').on('change', function() {
                renderDataTable();
            });
        });

        // Delete Button Click
        $(document).on('click', '.delete-btn', function() {
            const id = $(this).data('id');
            const deleteUrl = `<?php echo e(route('journal.voucher.delete', ':id')); ?>`.replace(':id', id);
            $('#deleteForm').attr('action', deleteUrl);
            $('#deleteModal').modal('show');
        });

        function renderDataTable() {
            const filter_voucher_number = $('#filter_voucher_number').val();
            const filter_amount = $('#filter_amount').val();
            const filter_reference = $('#filter_reference').val();
            const filter_date = $('#filter_date').val();

            // Destroy existing DataTable if it exists
            $('#journalTable').DataTable().destroy();

            // Initialize DataTable with AJAX
            $('#journalTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: '<?php echo e(route('journal.voucher.index')); ?>', // Route to get data
                    type: 'GET',
                    data: function(d) {
                        d.filter_voucher_number = filter_voucher_number;
                        d.filter_amount = filter_amount;
                        d.filter_reference = filter_reference;
                        if (isDateChanged) {
                            d.filter_date = filter_date; // Send date filter if it has changed
                        }
                    },
                    dataSrc: 'data'
                },
                columns: [{
                        data: 'id'
                    },
                    {
                        data: 'voucher_number'
                    },
                    {
                        data: 'reference'
                    },
                    {
                        data: 'date'
                    },
                    {
                        data: 'description'
                    },
                    {
                        data: 'total_debit'
                    },
                    {
                        data: 'actions'
                    } // Action column for edit, delete, and print
                ]
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blueMarketing\resources\views/admin/reports/vouchers/index.blade.php ENDPATH**/ ?>