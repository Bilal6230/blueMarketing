
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($title); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header p-2">
                                <ul class="nav nav-pills">
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="nav-item"><a class="nav-link <?php echo e($loop->iteration == 1 ? 'active':''); ?>" href="#<?php echo e($i->category); ?>" data-toggle="tab"><?php echo e(Str::ucfirst($i->category)); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <div class="card-body">
                                <div class="tab-content">
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $settings = \App\Models\Setting::where(['category' => $i->category])->get();
                                        ?>
                                        <div class="tab-pane <?php echo e($loop->iteration == 1 ? 'active':''); ?>" id="<?php echo e($i->category); ?>">
                                            <form class="form-horizontal" action="<?php echo e(route('setting.update')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $set): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="form-group row">
                                                        <label for="<?php echo e($set->key); ?>" class="col-sm-2 col-form-label"><?php echo e(str_replace("Application ", "", $set->name)); ?></label>
                                                        <div class="col-sm-10">
                                                            <?php if($set->type == 'text'): ?>
                                                                <input type="hidden" name="key[]" value="<?php echo e($set->key); ?>">
                                                                <input type="text" name="value[]" value="<?php echo e($set->value); ?>" class="form-control" id="<?php echo e($set->key); ?>" placeholder="<?php echo e($set->name); ?>" required>
                                                            <?php elseif($set->type == 'textarea'): ?>
                                                                <input type="hidden" name="key[]" value="<?php echo e($set->key); ?>">
                                                                <textarea type="text" name="value[]" rows="3" class="form-control" id="<?php echo e($set->key); ?>" placeholder="<?php echo e($set->name); ?>" required><?php echo e($set->value); ?></textarea>
                                                            <?php elseif($set->type == 'file'): ?>
                                                                <img src="<?php echo e(asset($set->value)); ?>" alt="<?php echo e($set->name); ?>" id="<?php echo e($set->key); ?>-image" width="8%">
                                                                <div class="input-group">
                                                                    <input type="hidden" name="key[]" value="<?php echo e($set->key); ?>">
                                                                    <input type="text" readonly class="form-control" placeholder="<?php echo e($set->name); ?>" name="value[]" id="<?php echo e($set->key); ?>" value="<?php echo e($set->value); ?>" readonly required>
                                                                    
                                                                </div>
                                                                <small class="text-primary">Click to select file</small>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <div class="form-group row">
                                                    <div class="offset-sm-2 col-sm-10">
                                                        <button type="submit" class="btn btn-primary">Save</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php
        $setts = \App\Models\Setting::where(['type' => 'file'])->get();
    ?>
    <?php $__currentLoopData = $setts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $set): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $setid[] = '#'.$set->key;
            $jsonsetid = json_encode($setid, true);
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <script>
        $(document).ready(function() {
            // input
            let inputId = '';
            function fmSetLink($url) {
                $(inputId).val($url.substring(1));
                $(inputId+'-image').attr("src", "<?php echo e(asset(null)); ?>"+$url.substring(1));
            }
            
            window.fmSetLink = fmSetLink;

            $(document).on("click", '<?php echo e(implode(',', $setid)); ?>', function(event) {
                event.preventDefault();
                inputId = '#'+event.target.id;
                window.open('/file-manager/fm-button', 'fm', 'width=800,height=600');
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u541740294/domains/bluemarketing.com.pk/public_html/hr/resources/views/admin/setting.blade.php ENDPATH**/ ?>