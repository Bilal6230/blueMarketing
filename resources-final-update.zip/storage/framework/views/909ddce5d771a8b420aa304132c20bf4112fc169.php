<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4>Plot Booking History - <?php echo e($plot->name); ?></h4>
        </div>
        <div class="card-body">
            <?php if(count($plotHistory) > 0): ?>
                <table class="table table-striped">
                    <thead class="thead-dark">
                        <tr>
                            <th>Booking ID</th>
                            <th>Customer</th>
                            <th>Plot Size</th>
                            <th>Rate</th>
                            <th>Total Price</th>
                            <th>Broker</th>
                            <th>Booking Date</th>
                            <th>Deleted At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $plotHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($history['booking_id']); ?></td>
                                <td><?php echo e($history['name']); ?> (<?php echo e($history['cnic']); ?>)</td>
                                <td><?php echo e($history['plot_size']); ?></td>
                                <td><?php echo e(number_format($history['plot_rate'])); ?></td>
                                <td><?php echo e(number_format($history['total_price'])); ?></td>
                                <td><?php echo e($history['broker_id'] ?? 'N/A'); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($history['booking_date'])->format('d M Y')); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($history['deleted_at'])->format('d M Y, h:i A')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-center">No booking history available for this plot.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u541740294/domains/bluemarketing.com.pk/public_html/hr/resources/views/admin/plots/history.blade.php ENDPATH**/ ?>