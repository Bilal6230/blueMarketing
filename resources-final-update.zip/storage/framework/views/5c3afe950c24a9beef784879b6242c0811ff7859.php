<?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr data-id="<?php echo e($site->id); ?>" data-name="<?php echo e($site->site_name); ?>" data-address="<?php echo e($site->site_address); ?>">
        <td><?php echo e($site->site_name); ?></td>
        <td><?php echo e($site->site_address); ?></td>
        <td><button class="btn editSiteBtn" data-id="<?php echo e($site->id); ?>"
                siteData="<?php echo e(json_encode($site)); ?>">Edit</button>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\blueMarketing\resources\views/admin/labours/sites.blade.php ENDPATH**/ ?>