

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-primary"><?php echo e($title); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <!-- Stats Overview -->
                <div class="row mb-4">
                    <div class="col-12">
                        <h2 class="section-title"><i class="fas fa-chart-line"></i> Statistics Overview</h2>
                    </div>
                    
                    <!-- Total Plots -->
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-card total-plots">
                            <div class="stat-icon">
                                <i class="fas fa-map-marked-alt"></i>
                            </div>
                            <div class="stat-content">
                                <h3 class="stat-number"><?php echo e($chartData['total']); ?></h3>
                                <p class="stat-label">Total Plots</p>
                                <div class="stat-breakdown">
                                    <span class="breakdown-item">
                                        <i class="fas fa-home"></i> Residential: <?php echo e($residentialChartData['sold'] + $residentialChartData['unsold'] + $residentialChartData['hold']); ?>

                                    </span>
                                    <span class="breakdown-item">
                                        <i class="fas fa-store"></i> Shops: <?php echo e($shopsChartData['sold'] + $shopsChartData['unsold'] + $shopsChartData['hold']); ?>

                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Sold Plots -->
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-card sold-plots">
                            <div class="stat-icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <div class="stat-content">
                                <h3 class="stat-number"><?php echo e($chartData['sold']); ?></h3>
                                <p class="stat-label">Sold Plots</p>
                                <div class="stat-breakdown">
                                    <span class="breakdown-item">
                                        <i class="fas fa-home"></i> Residential: <?php echo e($residentialChartData['sold']); ?>

                                    </span>
                                    <span class="breakdown-item">
                                        <i class="fas fa-store"></i> Shops: <?php echo e($shopsChartData['sold']); ?>

                                    </span>
                                </div>
                            </div>
                            <div class="stat-percentage">
                                <?php echo e(round(($chartData['sold'] / $chartData['total']) * 100, 1)); ?>%
                            </div>
                        </div>
                    </div>
                    
                    <!-- Unsold Plots -->
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-card unsold-plots">
                            <div class="stat-icon">
                                <i class="fas fa-times-circle"></i>
                            </div>
                            <div class="stat-content">
                                <h3 class="stat-number"><?php echo e($chartData['unsold']); ?></h3>
                                <p class="stat-label">Unsold Plots</p>
                                <div class="stat-breakdown">
                                    <span class="breakdown-item">
                                        <i class="fas fa-home"></i> Residential: <?php echo e($residentialChartData['unsold']); ?>

                                    </span>
                                    <span class="breakdown-item">
                                        <i class="fas fa-store"></i> Shops: <?php echo e($shopsChartData['unsold']); ?>

                                    </span>
                                </div>
                            </div>
                            <div class="stat-percentage">
                                <?php echo e(round(($chartData['unsold'] / $chartData['total']) * 100, 1)); ?>%
                            </div>
                        </div>
                    </div>
                    
                    <!-- Hold Plots -->
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-card hold-plots">
                            <div class="stat-icon">
                                <i class="fas fa-pause-circle"></i>
                            </div>
                            <div class="stat-content">
                                <h3 class="stat-number"><?php echo e($chartData['hold']); ?></h3>
                                <p class="stat-label">Hold Plots</p>
                                <div class="stat-breakdown">
                                    <span class="breakdown-item">
                                        <i class="fas fa-home"></i> Residential: <?php echo e($residentialChartData['hold']); ?>

                                    </span>
                                    <span class="breakdown-item">
                                        <i class="fas fa-store"></i> Shops: <?php echo e($shopsChartData['hold']); ?>

                                    </span>
                                </div>
                            </div>
                            <div class="stat-percentage">
                                <?php echo e(round(($chartData['hold'] / $chartData['total']) * 100, 1)); ?>%
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Charts Section -->
                <div class="row mb-4">
                    <div class="col-12">
                        <h2 class="section-title"><i class="fas fa-chart-pie"></i> Visual Analytics</h2>
                    </div>
                    
                    <!-- Total Plots Overview -->
                    <div class="col-md-3">
                        <div class="chart-card">
                            <div class="chart-header">
                                <h3 class="chart-title"><i class="fas fa-chart-pie"></i> Plots Overview</h3>
                            </div>
                            <div class="chart-body">
                                <canvas id="plotsChart"></canvas>
                            </div>
                            
                        </div>
                    </div>

                    <!-- Size Distribution -->
                    <div class="col-md-3">
                        <div class="chart-card">
                            <div class="chart-header">
                                <h3 class="chart-title"><i class="fas fa-ruler-combined"></i> Size Distribution</h3>
                            </div>
                            <div class="chart-body">
                                <canvas id="sizeChart"></canvas>
                            </div>
                            
                        </div>
                    </div>

                    <!-- Residential Plots -->
                    <div class="col-md-3">
                        <div class="chart-card">
                            <div class="chart-header">
                                <h3 class="chart-title"><i class="fas fa-home"></i> Residential Plots</h3>
                            </div>
                            <div class="chart-body">
                                <canvas id="residentialChart"></canvas>
                            </div>
                            
                        </div>
                    </div>

                    <!-- Shops Plots -->
                    <div class="col-md-3">
                        <div class="chart-card">
                            <div class="chart-header">
                                <h3 class="chart-title"><i class="fas fa-store"></i> Shops</h3>
                            </div>
                            <div class="chart-body">
                                <canvas id="shopsChart"></canvas>
                            </div>
                            
                        </div>
                    </div>
                </div>

                <!-- Shops Section -->
                <div class="row mb-4">
                    <div class="col-12">
                        <h2 class="section-title"><i class="fas fa-store"></i> Shops Overview</h2>
                    </div>
                    <!-- Sold Shops -->
                    <div class="col-md-4">
                        <div class="status-card sold">
                            <div class="status-header">
                                <h4 class="m-0"><i class="fas fa-store"></i> Sold Shops (<?php echo e($soldShops->count()); ?>)</h4>
                            </div>
                            <div class="status-body">
                                <?php $__currentLoopData = $soldShops->chunk(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="plot-row">
                                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="plot-tag"><?php echo e($plot->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>

                    <!-- Unsold Shops -->
                    <div class="col-md-4">
                        <div class="status-card unsold">
                            <div class="status-header">
                                <h4 class="m-0"><i class="fas fa-store"></i> Unsold Shops (<?php echo e($unsoldShops->count()); ?>)</h4>
                            </div>
                            <div class="status-body">
                                <?php $__currentLoopData = $unsoldShops->chunk(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="plot-row">
                                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="plot-tag"><?php echo e($plot->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Hold Shops -->
                    <div class="col-md-4">
                        <div class="status-card hold">
                            <div class="status-header">
                                <h4 class="m-0"><i class="fas fa-store"></i> Hold Shops (<?php echo e($holdShops->count()); ?>)</h4>
                            </div>
                            <div class="status-body">
                                <?php $__currentLoopData = $holdShops->chunk(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="plot-row">
                                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="plot-tag"><?php echo e($plot->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Residential Plots Section -->
                <div class="row">
                    <div class="col-12">
                        <h2 class="section-title"><i class="fas fa-home"></i> Residential Plots Overview</h2>
                    </div>
                    <!-- Sold Residential Plots -->
                    <div class="col-md-4">
                        <div class="status-card sold">
                            <div class="status-header">
                                <h4 class="m-0"><i class="fas fa-home"></i> Sold Residential (<?php echo e($soldResidential->count()); ?>)</h4>
                            </div>
                            <div class="status-body">
                                <?php $__currentLoopData = $soldResidential->chunk(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="plot-row">
                                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="plot-tag"><?php echo e($plot->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>

                    <!-- Unsold Residential Plots -->
                    <div class="col-md-4">
                        <div class="status-card unsold">
                            <div class="status-header">
                                <h4 class="m-0"><i class="fas fa-home"></i> Unsold Residential (<?php echo e($unsoldResidential->count()); ?>)</h4>
                            </div>
                            <div class="status-body">
                                <?php $__currentLoopData = $unsoldResidential->chunk(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="plot-row">
                                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="plot-tag"><?php echo e($plot->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Hold Residential Plots -->
                    <div class="col-md-4">
                        <div class="status-card hold">
                            <div class="status-header">
                                <h4 class="m-0"><i class="fas fa-home"></i> Hold Residential (<?php echo e($holdResidential->count()); ?>)</h4>
                            </div>
                            <div class="status-body">
                                <?php $__currentLoopData = $holdResidential->chunk(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="plot-row">
                                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="plot-tag"><?php echo e($plot->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
  
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        function createPieChart(canvasId, labels, data, colors) {
            new Chart(document.getElementById(canvasId), {
                type: 'pie',
                data: {
                    labels: labels,
                    datasets: [{
                        data: data,
                        backgroundColor: colors,
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 15,
                                usePointStyle: true,
                                pointStyle: 'circle',
                                font: {
                                    size: 11
                                }
                            }
                        }
                    }
                }
            });
        }

        // Chart Data
        createPieChart('plotsChart', ['Sold', 'Unsold', 'Hold'],
            [<?php echo e($chartData['sold']); ?>, <?php echo e($chartData['unsold']); ?>, <?php echo e($chartData['hold']); ?>],
            ['#11998e', '#ff416c', '#f7971e']);

        createPieChart('sizeChart', ['Sold', 'Unsold', 'Hold'],
            [<?php echo e($sizeChartData['soldSize']); ?>, <?php echo e($sizeChartData['unsoldSize']); ?>, <?php echo e($sizeChartData['holdSize']); ?>],
            ['#667eea', '#11998e', '#ff416c', '#f7971e']);

        createPieChart('residentialChart', ['Sold', 'Unsold', 'Hold'],
            [<?php echo e($residentialChartData['sold']); ?>, <?php echo e($residentialChartData['unsold']); ?>, <?php echo e($residentialChartData['hold']); ?>],
            ['#11998e', '#ff416c', '#f7971e']);

        createPieChart('shopsChart', ['Sold', 'Unsold', 'Hold'],
            [<?php echo e($shopsChartData['sold']); ?>, <?php echo e($shopsChartData['unsold']); ?>, <?php echo e($shopsChartData['hold']); ?>],
            ['#11998e', '#ff416c', '#f7971e']);
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blueMarketing\resources\views/admin/plots/inventory.blade.php ENDPATH**/ ?>