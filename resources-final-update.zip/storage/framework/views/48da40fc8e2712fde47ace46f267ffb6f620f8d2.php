<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <span class="<?php echo e($class); ?>">
                            <?php echo e($title); ?>

                        </span>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add slip')): ?>
                                <div class="card-header">
                                    <div>
                                        <form action="<?php echo e(route('booking.customer.deposit')); ?>" method="POST" enctype="multipart/form-data" id="voucherForm">
                                            <?php echo csrf_field(); ?>

                                            <div class="row">

                                                <div class="col-sm-12">
                                                    <div class="row">
                                                        <div class="col-sm-3">
                                                            <div class="input-group">
                                                                <label class="fbox">Voucher No.</label>
                                                                <div class="input-group">
                                                                    <input type="text" value="deposit" name="action" hidden /> 
                                                                    <input type="text"  class="form-control " name="voucher" value="<?php echo e($type); ?>-<?php echo e(get_new_booking_voucher($type)); ?>" autocomplete="off" readonly>
                                                                    
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-sm-3">
                                                            <div class="input-group">
                                                                <label class="fbox">Slip No.</label>
                                                                <div class="input-group">
                                                                   
                                                                    <input type="text" class="form-control <?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="reference" value="<?php echo e(old('reference')); ?>" autocomplete="off">
                                                                    <?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-sm-6">
                                                            <div class="input-group">
                                                                <label class="fbox">Date</label>
                                                                <div class="input-group">
                                                                    <input type="text" name="date" class="date form-control" data-input>
                                                                    <!-- Add a hidden input to store the selected date in a format you want -->
                                                                    <input type="hidden" id="hiddenDate" name="hiddenDate">
                                                                    
                                                                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>

                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div class="row">
                                                        <div class="col-sm-6">
                                                            <div class="input-group">
                                                                <label class="fbox">Projects</label>
                                                                <div class="input-group">
                                                                    <select class="form-control select2" name="project_id" id="project_id">
                                                                        <option value="">Select an option</option>
        
                                                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($v->id); ?>"><?php echo e($v->project); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                    <?php $__errorArgs = ['project_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-sm-6">
                                                            <div class="input-group">
                                                                <label class="fbox">Customer</label>
                                                                <div class="input-group">
                                                                    <select class="form-control select2" name="customer_id" id="customer_id">
                                                                        <option value="">Select Customer</option>
        
                                                                        
                                                                    </select>
                                                                    <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="row">
                                                        <div class="col-sm-6">
                                                            <div class="input-group">
                                                                <label class="fbox">Plot No.</label>
                                                                <div class="input-group">
                                                                    <select class="form-control select2" name="plot_id" id="plot_id">
                                                                        <option value="">Select Plot</option>
                                                                    </select>
                                                                    <?php $__errorArgs = ['plot_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <div class="input-group">
                                                                <label class="fbox">Amount</label>
                                                                <div class="input-group">
                                                                    <input id="numberInput" oninput="formatAmount(this)" type="text" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Amount" name="amount" value="<?php echo e(old('amount')); ?>"  >
                                                                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                    </div>
                                                </div>

                                                
                                                
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div id="wordingAmount"></div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12">
                                                <div class="row">
                                                    <div class="col-sm-3">
                                                        <div class="input-group">
                                                            <label class="fbox">Payment Type</label>
                                                            <div class="input-group">
                                                                <select class="form-control select2" name="payment_type" id="payment_type">
                                                                    <option value="1">Cash</option>
                                                                    <option value="2">Online</option>
                                                                    <option value="3">Check</option>
                                                                </select>
                                                                <?php $__errorArgs = ['payment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <div class="input-group bank_group"  style="display: none"  >
                                                            <label class="fbox">Number</label>
                                                            <div class="input-group">
                                                                <input id="t_number" type="text" class="form-control <?php $__errorArgs = ['t_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Transaction Number" name="t_number" value="<?php echo e(old('t_number')); ?>"  >
                                                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-3" >
                                                        <div class="input-group bank_group" style="display: none">
                                                            <label class="fbox">Bank</label>
                                                            <div class="input-group">
                                                                <select class="form-control select2" name="bank_id" id="bank_id">
                                                                    <option value="">Bank</option>
    
                                                                    <?php $__currentLoopData = getPakistanBanks(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($v['id']); ?>"><?php echo e($v['name']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                            
                                                        </div>
                                                    </div>

                                                    <div class="col-sm-3"  >
                                                        <div class="input-group bank_group" style="display: none">
                                                            <label class="fbox">Passing Date</label>
                                                            <div class="input-group">
                                                                <input type="text" name="passing_date" class="date form-control" data-input>
                                                                <!-- Add a hidden input to store the selected date in a format you want -->
                                                                <?php $__errorArgs = ['passing_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                </div>
                                            </div>
                                            
                                            <div class="row">

                                                <div class="col-sm-12">
                                                    <div class="row">
                                                        <div class="col-sm-6">
                                                            <div class="input-group <?php echo e($bg_voucher); ?>">
                                                                <div class="input-group">
                                                                    <textarea class="form-control <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Detail" name="detail" style=" height: 150px;" maxlength="255" ><?php echo e(old('detail')); ?></textarea>
                                                                    <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-sm-6">
                                                            <div class="<?php echo e($bg_voucher); ?>">
                                                                <div class="party-info">
                                                                    
                                                                    <div class="info-set">
                                                                        <strong class="info-label">Phone:</strong>
                                                                        <span id="phone" class="info-data"></span><br>
                                                                    </div>

                                                                    <div class="info-set">
                                                                        <strong class="info-label">Address:</strong>
                                                                        <span id="address" class="info-data"></span><br>
                                                                    </div>

                                                                    <div class="info-set">
                                                                        <strong class="info-label">CNIC:</strong>
                                                                        <span id="cnic" class="info-data"></span><br>
                                                                    </div>
                                                                    
                                                                    <div class="info-set">
                                                                        <strong class="info-label">Due Amount:</strong>
                                                                        <span id="due" class="info-data"></span>
                                                                    </div>

                                                                    <div class="info-set">
                                                                        <strong class="info-label">Balance:</strong>
                                                                        <span id="balance" class="info-data"></span>
                                                                    </div>
                                                                </div>
                                                                
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                    

                                                

                                                
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    
    
                                                    <div class="col-sm-3">
                                                        <div class="modal-footer justify-content-between">
                                                            <button type="button" class="btn btn-primary btn-lg btn-block" data-toggle="modal" data-target="#confirmModal">Save</button>


                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <!-- /.card-header -->
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read slip')): ?>
                                <div class="card-body table-responsive">
                                    <table id="example1" class="table table-striped table-bordered " style="width:100%">
                                        <thead>
                                            <tr>
                                                <th style="width: 5px">#</th>
                                                <th style="width: 60px">Date</th>
                                                
                                                <th>Customer</th>
                                                <th style="width: 5px">Plot</th>
                                                <th style="width: 5px">Ref</th>
                                                <th>Detail</th>
                                                <th>Amount</th>
                                                <th>Type</th>
                                                <th>Approve</th>


                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['delete slip','can approve'])): ?>
                                                    <th>Action</th>
                                                <?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td>
                                                        <?php echo e($i->date ?? ''); ?>

                                                    </td>
                                                    
                                                    <td>
                                                        <?php echo e($i->customer_list->first_name ?? ''); ?> <?php echo e($i->customer_list->last_name ?? ''); ?>  <?php echo e($i->customer_list->relate ?? ''); ?> <?php echo e($i->customer_list->last_name ?? ''); ?> 
                                                    </td>
                                                    <td>
                                                        <?php echo e($i->plot_list->name ?? ''); ?>


                                                    </td>
                                                    <td>
                                                        <?php echo e($i->reference ?? ''); ?>


                                                    </td>
                                                    <td>
                                                        <?php echo e($i->description); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e(Setting::roundformatAmount($i->amount_out)); ?>

                                                    </td>
                                                    
                                                    <td>
                                                        <span class="badge <?php echo e(getPaymentTypeDetails($i->payment_type)['badge']); ?>" style="width: 80%">
                                                            <?php echo e(getPaymentTypeDetails($i->payment_type)['name']); ?>

                                                        </span>
                                                    </td>

                                                    <td>
                                                        <?php echo e(approveStatus($i->is_approve)); ?>

                                                    </td>
                                                    
                                                    
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['update voucher','delete slip','can approve'])): ?>
                                                        <td>
                                                            <div class="btn-group">
                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update voucher')): ?>
                                                                    <button class="btn btn-sm btn-primary btn-edit" data-id="<?php echo e($i->id); ?>"><i class="fas fa-pencil-alt"></i></button>
                                                                <?php endif; ?>
                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('can approve')): ?>
                                                                    <button class="btn btn-sm btn-secondary btn-view" data-id="<?php echo e($i->id); ?>" data-name="<?php echo e($i->name); ?>"><i class="fas fa-eye"></i></button>
                                                                <?php endif; ?>
                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete slip')): ?>
                                                                    <button class="btn btn-sm btn-danger btn-delete" data-id="<?php echo e($i->id); ?>" data-name="<?php echo e($i->name); ?>"><i class="fas fa-trash"></i></button>
                                                                <?php endif; ?>
                                                                
                                                            </div>
                                                        </td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            
                                        </tbody>

                                        
                                    </table>
                                </div>
                            <?php endif; ?>
                            
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->


                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

    
    <div class="modal fade" id="modal-edit">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header <?php echo e($class); ?>">
                    <h4 class="modal-title">Edit Voucher</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('ledger.update')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("PUT"); ?>
                        <div class="row">

                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <label class="fbox">Voucher No.</label>
                                            <div class="input-group">
                                                <input type="text" value="1" name="action" hidden /> 
                                                <input id="voucher" type="text"  class="form-control " name="voucher" autocomplete="off" readonly >
                                                
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <label class="fbox">Reference</label>
                                            <div class="input-group">
                                               
                                                <input id="reference" type="text" class="form-control <?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="reference" value="<?php echo e(old('reference')); ?>" autocomplete="off">
                                                <?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <label class="fbox">Date</label>
                                            <div class="input-group">
                                                <input type="text" id="date" name="date" class="date_database form-control" data-input>
                                                <!-- Add a hidden input to store the selected date in a format you want -->
                                                
                                                
                                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>

                        <div class="row">
                            <div class="col-sm-6">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <label class="fbox">Projects</label>
                                            <div class="input-group">
                                                <select class="form-control select2" name="projects_id" id="e_projects_id">
                                                    <option value="">Select an option</option>

                                                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($v->id); ?>"><?php echo e($v->project); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['projects_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <label class="fbox">Accounts</label>
                                            <div class="input-group">
                                                <select class="form-control select2" name="accounts_id" id="e_accounts_id">
                                                    <option value="">Select an option</option>

                                                    
                                                </select>
                                                <?php $__errorArgs = ['accounts_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <label class="fbox">Party Account</label>
                                            <div class="input-group">
                                                <select class="form-control select2" name="subaccounts_id" id="e_subaccounts_id">
                                                    <option value="">Select an option</option>
                                                </select>
                                                <?php $__errorArgs = ['subaccounts_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <label class="fbox">Amount</label>
                                            <div class="input-group">
                                                <input id="amount" oninput="formatAmount(this)" type="text" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Amount" name="amount" value="<?php echo e(old('amount')); ?>"  >
                                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                </div>
                            </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="input-group">
                                    <label class="fbox">Detail</label>
                                    <div class="input-group">
                                        <textarea id="detail" class="form-control <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Detail" name="detail" style=" height: 150px;" maxlength="255" ><?php echo e(old('detail')); ?></textarea>
                                        <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        
                        <div class="modal-footer justify-content-between">
                            <input type="hidden" name="id" id="id">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
    </div>
    
    <div class="modal fade" id="modal-delete">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Delete Voucher</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('booking.customer.destroy')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <p class="modal-text">Are you sure you want to delete? <b id="delete-data"></b></p>
                        <input type="hidden" name="id" id="did">
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                    <button type="submit" class="btn btn-danger">Yes</button>
                </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    
    <div class="modal fade" id="modal-approve">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Approve Voucher</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('booking.customer.approve')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <p class="modal-text" id="msg">Are you sure you want to Approve? <b id="delete-data"></b></p>
                        <input type="hidden" name="id" class="status_id">
                        <input type="hidden" name="is_approve" class="is_approve" value="0">
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                    <button type="submit" class="btn btn-danger">Yes</button>
                </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    
    <div class="modal fade" id="modal-view">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header <?php echo e($class); ?>">
                    <h4 class="modal-title">View Slip</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('ledger.update')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("PUT"); ?>
                        <div class="row">

                            <div class="col-sm-6">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <span>Slip</span>
                                    </div>
                                    <div class="col-sm-6">
                                        <span>Slip Number </span>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <span>Customer</span>
                                    </div>
                                    <div class="col-sm-6">
                                        <span>Ali </span>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <span>Plot</span>
                                    </div>
                                    <div class="col-sm-6">
                                        <span>Ali </span>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <span>Plot</span>
                                    </div>
                                    <div class="col-sm-6">
                                        <span>Ali </span>
                                    </div>

                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <span>Date</span>
                                    </div>
                                    <div class="col-sm-6">
                                        <span>Date Here</span>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <span>Phone</span>
                                    </div>
                                    <div class="col-sm-6">
                                        <span>Date Here</span>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <span>Size</span>
                                    </div>
                                    <div class="col-sm-6">
                                        <span>Date Here</span>
                                    </div>

                                </div>
                            </div>
                            
                        </div>

                        
                        <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default btn-rejected" data-dismiss="modal" data-id='' data-name=''>Rejected</button>
                            <button type="button" class="btn btn-primary btn-approve" data-dismiss="modal" data-id='' data-name='' >Approve</button>

                        </div>
                    </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>

            function submitForm() {
                document.getElementById('voucherForm').submit();
            }


        $(document).ready(function() {

            $(document).ready(function() {
                console.log("Document ready");
                $('#payment_type').change(function(e) {
                   
                    e.preventDefault();
                    
                    if ($(this).val() != '1') {
                        
                        $('.bank_group').css('display', 'block');
                    } else {
                        
                        $('.bank_group').css('display', 'none');
                    }
                });
            });

            function fetchCustomers(projectId) {
                $.ajax({
                    url: '/admin/get-customers-byplot', // URL to your route
                    type: 'POST', // Use POST method for sending data
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>', // Add CSRF token
                        project_id: projectId // Pass project ID to server
                    },
                    success: function(data) {
                        // Populate customer dropdown with retrieved data
                        $('#customer_id').empty();
                        $('#customer_id').append('<option value="">Select customer</option>');
                        $.each(data, function(key, customer) {
                            $('#customer_id').append('<option value="' + customer.id + '" data-phone="'+ customer.mobile_number +'" data-nic_number="'+ customer.nic_number +'" data-home_address="'+ customer.home_address +'">' + customer.first_name + ' ' + customer.last_name + ' '+ customer.relate +' '+ customer.father_name + ' - ' + customer.phone_number + '</option>');
                        });
                    }
                });
            }

            
            // Event listener for project dropdown change
            $('#project_id').change(function() {
                // Get selected project ID
                var projectId = $(this).val();

                // If a project is selected, fetch customers
                if (projectId) {
                    fetchCustomers(projectId);
                } else {
                    // If no project is selected, empty the customer dropdown
                    $('#customer_id').empty();
                    $('#customer_id').append('<option value="">Select customer</option>');
                }
            });

            $('#customer_id').change(function (e) { 
                e.preventDefault();
                var customerId = $(this).val();

                if (customerId) {
                    fetchPlots(customerId);
                    // console.log($(this).data('phone'));
                    // $('#phone').text( 'asdas');
                } else {
                    // If no project is selected, empty the customer dropdown
                    $('#plot_id').empty();
                    $('#plot_id').append('<option value="">Select plots</option>');
                }
                    
            });

            function fetchPlots(customerId) {
                $.ajax({
                    url: '/admin/get-plots-list', // URL to your route
                    type: 'POST', // Use POST method for sending data
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>', // Add CSRF token
                        project_id: '<?php echo e(getSelectedTown()); ?>',
                        customer_id: customerId // Pass project ID to server
                    },
                    success: function(data) {
                        console.log(data);
                        // Populate customer dropdown with retrieved data
                        $('#plot_id').empty();
                        $('#plot_id').append('<option value="">Select Plots</option>');
                        $.each(data, function(key, plot) {
                            var plotType = (plot.type == 1) ? 'R- ' : 'C- ';
                            $('#plot_id').append('<option value="' + plot.plot_id + '">' + plotType + ' ' + plot.name +  '  </option>');
                        });
                    }
                });
            }

          

            $('#numberInput').on('input', function() {
                convertToWords();
            });

            $(document).on("click", '.btn-delete', function() {
                let id = $(this).attr("data-id");
                let name = $(this).attr("data-name");
                $("#did").val(id);
                $('#modal-delete').modal({backdrop: 'static', keyboard: false, show: true});
            });

            $(document).on("click", '.btn-view', function() {
                debugger;
                let id = $(this).attr("data-id");
                $('#modal-loading').modal({backdrop: 'static', keyboard: false, show: true});
                $.ajax({
                    url: "<?php echo e(route('booking.voucher.show')); ?>",
                    type: "POST",
                    dataType: "JSON",
                    data: {
                        id: id,
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(data) {
                        debugger;
                        var data = data.data;
                        $("#id").val(data.id);
                        $("#reference").val(data.reference);
                        $('.btn-approve').attr('data-id', data.id);
                        $('.btn-rejected').attr('data-id', data.id);
                        
                        
                        
                        $("#description").val(data.description);

                        $('#modal-loading').modal('hide');
                        $('#modal-view').modal({backdrop: 'static', keyboard: false, show: true});
                    },
                });
            });

            $(document).on("click", '.btn-approve', function() {
                let id = $(this).attr("data-id");
                $(".status_id").val(id);
                $(".is_approve").val(1);
                $('#msg').text("Are you sure you want to Approve?");
                $('#modal-approve').modal({backdrop: 'static', keyboard: false, show: true});
            });
            $(document).on("click", '.btn-rejected', function() {
                let id = $(this).attr("data-id");
                $(".status_id").val(id);
                $(".is_approve").val(2);
                $('#msg').text("Are you sure you want to rejected?");
                $('#modal-approve').modal({backdrop: 'static', keyboard: false, show: true});
            });
            

            

            
        });

        function convertToWords() {
            // Get the value entered in the input field
            var numberInput = document.getElementById('numberInput').value;

            // Remove commas for thousands separator
            var numericValue = numberInput.replace(/,/g, '');

            // Convert the entered number to English wording
            var wordingAmount = numberToWords.toWords(numericValue);

            // Display the English wording amount in the container
            document.getElementById('wordingAmount').innerText = wordingAmount;
        }

        function formatAmount(input) {
                // Remove non-numeric characters and leading zeros
                let value = input.value.replace(/[^0-9]/g, '').replace(/^0+/, '');

                // Add commas for thousands separator
                value = value.replace(/\B(?=(\d{3})+(?!\d))/g, ',');

                // Update the input value
                input.value = value;
            }

            
    </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u541740294/domains/bluemarketing.com.pk/public_html/hr/resources/views/admin/booking/receive.blade.php ENDPATH**/ ?>