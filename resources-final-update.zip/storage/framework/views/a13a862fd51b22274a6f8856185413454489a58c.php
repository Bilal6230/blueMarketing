
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($title); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create role')): ?>
                            <div class="card-header">
                                <h3 class="card-title">
                                    <button class="btn btn-sm btn-success" id="btn-tambah"><i class="fas fa-plus"></i> Add</button>
                                </h3>
                            </div>
                            <?php endif; ?>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive">
                                <table class="table table-bordered table-hover datatable">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Guard</th>
                                            <th>Permission</th>
                                            <th>Updated</th>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['update role', 'delete role'])): ?>
                                                <th>Action</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($i->name); ?></td>
                                                <td><?php echo e($i->guard_name); ?></td>
                                                <td>
                                                    <?php if($i->name == 'superadmin' || count($i->permissions) == count($permission)): ?>
                                                        All permission
                                                    <?php else: ?>
                                                        <?php echo e($i->permissions->implode('name', '|')); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($i->updated_at); ?></td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['update role', 'delete role'])): ?>
                                                    <td>
                                                        <div class="btn-group">
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update role')): ?>
                                                                <?php if($i->name != 'superadmin'): ?>
                                                                    <button class="btn btn-sm btn-primary btn-edit" data-id="<?php echo e($i->id); ?>"><i class="fas fa-pencil-alt"></i></button>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete role')): ?>
                                                                <?php if($i->name != 'superadmin'): ?>
                                                                    <button class="btn btn-sm btn-danger btn-delete" data-id="<?php echo e($i->id); ?>" data-name="<?php echo e($i->name); ?>"><i class="fas fa-trash"></i></button>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $(document).on("click", '#btn-tambah', function() {
                $('input:checkbox').prop('checked', false);
                $('#modal-tambah').modal({backdrop: 'static', keyboard: false, show: true});
            });
            $(document).on("click", '.btn-edit', function() {
                let id = $(this).attr("data-id");
                $('#modal-loading').modal({backdrop: 'static', keyboard: false, show: true});
                $.ajax({
                    url: "<?php echo e(route('role.show')); ?>",
                    type: "POST",
                    dataType: "JSON",
                    data: {
                        id: id,
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(data) {
                        // console.log(data.data.permissions);
                        var data = data.data;
                        var permissions = data.permissions;
                        if (permissions.length == <?php echo e(count($permission)); ?>) {
                            $("#checkAllu").prop('checked', true);
                        }else{
                            $("#checkAllu").prop('checked', false);
                        }
                        if (data.name == 'superadmin') {
                            $('input:checkbox.permission').prop('checked', true);
                            $('input:checkbox.permission').prop('disabled', true);
                            $("#checkAllu").prop('checked', true);
                            $("#checkAllu").prop('disabled', true);
                        }else{
                            $('input:checkbox.permission').prop('checked', false);
                            $('input:checkbox.permission').prop('disabled', false);
                            $("#checkAllu").prop('disabled', false);
                        }
                        for (let i = 0; i < permissions.length; i++) {
                            $(`#${permissions[i].id}u`).prop('checked', true);
                        }
                        $("#name").val(data.name);
                        $("#guard_name").val(data.guard_name);
                        $("#id").val(data.id);
                        $('#modal-loading').modal('hide');
                        $('#modal-edit').modal({backdrop: 'static', keyboard: false, show: true});
                    },
                });
            });
            
            $(document).on("click", '.btn-delete', function() {
                let id = $(this).attr("data-id");
                let name = $(this).attr("data-name");
                $("#did").val(id);
                $("#delete-data").html(name);
                $('#modal-delete').modal({backdrop: 'static', keyboard: false, show: true});
            });

            $("#checkAll").click(function(){
                $('input:checkbox').not(this).prop('checked', this.checked);
            });

            $("#checkAllu").click(function(){
                $('input:checkbox').not(this).prop('checked', this.checked);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    
    <div class="modal fade" id="modal-tambah">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Tambah Data</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('role.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="input-group">
                            <label>Name</label>
                            <div class="input-group">
                                <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Name" name="name" value="<?php echo e(old('name')); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="input-group">
                            <label>Guard</label>
                            <div class="input-group">
                                <select class="form-control" name="guard_name">
                                    <option value="web">web</option>
                                    <option value="api">api</option>
                                </select>
                                <?php $__errorArgs = ['guard_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="input-group mt-2">
                            <label>Permission</label>
                        </div>
                        <div class="input-group">
                            <div class="icheck-primary col-md-3">
                                <input class="form-check-input" type="checkbox" id="checkAll">
                                <label class="form-check-label" for="checkAll">Check All</label>
                            </div>
                        </div>
                        <div class="input-group">
                            <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="icheck-primary col-md-3">
                                    <input class="form-check-input permission" type="checkbox" name="permissions[]" id="<?php echo e($p->id); ?>" value="<?php echo e($p->name); ?>">
                                    <label class="form-check-label <?php echo e(strtok($p->name, ' ') == 'delete' ? 'text-danger':''); ?>" for="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    
    <div class="modal fade" id="modal-edit">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit Data</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('role.update')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("PUT"); ?>
                        <div class="input-group">
                            <label>Name</label>
                            <div class="input-group">
                                <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Name" name="name" id="name" value="<?php echo e(old('name')); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="input-group">
                            <label>Guard</label>
                            <div class="input-group">
                                <select class="form-control" name="guard_name" id="guard_name">
                                    <option value="web">web</option>
                                    <option value="api">api</option>
                                </select>
                                <?php $__errorArgs = ['guard_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="input-group mt-2">
                            <label>Permission</label>
                        </div>
                        <div class="input-group">
                            <div class="icheck-primary col-md-3">
                                <input class="form-check-input" type="checkbox" id="checkAllu">
                                <label class="form-check-label" for="checkAllu">Check All</label>
                            </div>
                        </div>
                        <div class="input-group">
                            <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="icheck-primary col-md-3">
                                    <input class="form-check-input permission" type="checkbox" name="permissions[]" id="<?php echo e($p->id); ?>u" value="<?php echo e($p->name); ?>">
                                    <label class="form-check-label <?php echo e(strtok($p->name, ' ') == 'delete' ? 'text-danger':''); ?>" for="<?php echo e($p->id); ?>u"><?php echo e($p->name); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <input type="hidden" name="id" id="id">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    
    <div class="modal fade" id="modal-delete">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Hapus Data</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('role.destroy')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <p class="modal-text">Apakah anda yakin akan menghapus? <b id="delete-data"></b></p>
                        <input type="hidden" name="id" id="did">
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-danger">Hapus</button>
                </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\crm\resources\views/admin/role.blade.php ENDPATH**/ ?>