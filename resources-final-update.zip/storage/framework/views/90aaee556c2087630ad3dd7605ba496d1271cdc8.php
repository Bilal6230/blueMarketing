
<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($title); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cheque report')): ?>
                            <div class="card-header">
                                <h3 class="card-title">
                                </h3>
                                <form action="<?php echo e(route('report.check.post')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                <div class="row">


                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="customer">Customer</label>
                                            <select class="form-control select2" name="customer_id" id="customer_id">
                                                <option value="">Select Customer</option>
                                            </select>
                                            <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="customer">Plot</label>
                                            <select class="form-control select2" name="plot_id" id="plot_id">
                                                <option value=""> < All Plot > </option>
                                            </select>
                                            <?php $__errorArgs = ['plot_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="customer">Status</label>
                                            <select class="form-control select2" name="passing_status" id="passing_status">
                                                <option value=""> < All > </option>
                                                <?php $__currentLoopData = check_status(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($v['id']); ?>" <?php echo e($old_passing_status == $v['id'] ? 'selected' : ''); ?>><?php echo e($v['name']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['passing_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>


                                </div>
                                <div class="row">

                                    <div class="col-sm-3" >
                                        <div class="input-group bank_group">
                                            <label class="fbox">Bank</label>
                                            <div class="input-group">
                                                <select class="form-control select2" name="bank_id" id="bank_id">
                                                    <option value="">All Banks</option>

                                                    <?php $__currentLoopData = getPakistanBanks(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($v['id']); ?>" <?php echo e($old_bank_id == $v['id'] ? 'selected' : ''); ?>><?php echo e($v['name']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-sm-3" >
                                        <div class="input-group bank_group">
                                            <label class="fbox">Type</label>
                                            <div class="input-group">
                                                <select class="form-control select2" name="bank_id" id="bank_id">
                                                    <option value="">Payment Type</option>


                                                </select>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <label class="fbox">From Date</label>
                                            <div class="input-group">
                                                <input type="date" name="fdate" class=" form-control" data-input value="<?php echo e(old('fdate')); ?>">
                                                <?php $__errorArgs = ['fdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <label class="fbox">To Date</label>
                                            <div class="input-group">
                                                <input type="date" name="tdate" class="form-control" data-input value="<?php echo e(old('tdate')); ?>">
                                                <?php $__errorArgs = ['tdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-3">
                                        <div class="input-group d-flex align-items-end">
                                            <button class="btn btn-primary" id="searchfilter">Filter</button>
                                        </div>
                                    </div>
                                </div>

                                </form>

                            </div>
                            <?php endif; ?>
                            <!-- Total Sale Amount Card -->
                            <div class="col-md-4 " style="padding-top: 25px;">
                                <div class="card" style="background-color: #fd7e14; color: #fff; border-radius: 10px; ">
                                    <div class="card-body">
                                        <h5 class="card-title">Total Sale Amount</h5>
                                        <p class="card-text">
                                            <strong><?php echo e(Setting::formatAmount($totalAmountOut)); ?></strong>
                                        </p>
                                    </div>
                                </div>
                            </div>


                            <!-- /.card-header -->
                            <div class="card-body table-responsive">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Customer</th>
                                            <th>Phone</th>
                                            <th>Plot</th>
                                            <th>Type</th>
                                            <th>Transaction Type</th>
                                            <th>Bank</th>
                                            <th>Cheque No.</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                            <th>Note</th>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['pass cheque'])): ?>
                                                <th>Action</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td>
                                                    <?php echo e($i->customer_list->first_name); ?> <?php echo e($i->customer_list->last_name); ?>

                                                </td>
                                                <td><?php echo e($i->customer_list->phone_number); ?> </td>
                                                <td><?php echo e(Setting::getPlotTypeShort($i->plot_list->type)); ?>-<?php echo e($i->plot_list->name); ?> </td>
                                                <td>
                                                    <span class="badge <?php echo e(getPaymentTypeDetails($i->payment_type)['badge']); ?>" style="width: 80%">
                                                        <?php echo e(getPaymentTypeDetails($i->payment_type)['name']); ?>

                                                    </span>
                                                </td>
                                                <td><?php echo e($i->transaction_type ?? 'N/A'); ?></td>
                                                <td><?php echo e(getBankNameById($i->bank_id)); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('admin.reports.check_history', ['id' => $i->id])); ?>" target="_blank" class="btn btn-link">
                                                        <?php echo e($i->t_number); ?>

                                                    </a>
                                                </td>
                                                <td><?php echo e(Setting::formatAmount($i->amount_out)); ?></td>

                                                <td>
                                                    <span class="badge <?php echo e(collect(check_status())->firstWhere('id', $i->passing_status)['badge']); ?>" style="width: 80px">
                                                        <?php echo e(collect(check_status())->firstWhere('id', $i->passing_status)['name']); ?>

                                                    </span>
                                                </td>

                                                <td><?php echo e(Setting::getShortDate($i->passing_date)); ?></td>
                                                <td><?php echo e($i->note); ?></td>
                                                
                                                    <td>
                                                        
                                                            <div class="btn-group">
                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pass cheque')): ?>
                                                                    <button class="btn btn-sm btn-primary btn-edit" data-id="<?php echo e($i->id); ?>"><i class="fas fa-pencil-alt"></i></button>
                                                                <?php endif; ?>

                                                            </div>
                                                        


                                                    </td>
                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->


                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


    <script>
        // Define a JavaScript variable to hold installment options
        $(document).ready(function () {
            fetchCustomers('<?php echo e(getSelectedTown()); ?>');
            function fetchCustomers(projectId) {
                $.ajax({
                    url: '/admin/get-customers-byplot', // URL to your route
                    type: 'POST', // Use POST method for sending data
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>', // Add CSRF token
                        project_id: projectId // Pass project ID to server
                    },
                    success: function(data) {
                        // Populate customer dropdown with retrieved data
                        $('#customer_id').empty();
                        $('#customer_id').append('<option value="">Select customer</option>');
                        $.each(data, function(key, customer) {
                            $('#customer_id').append('<option value="' + customer.id + '">' + customer.first_name + ' ' + customer.last_name +' '+ customer.relate + ' '+ customer.father_name + ' - ' + customer.phone_number + '</option>');
                        });
                    }
                });
            }

            $('#customer_id').change(function (e) {
                e.preventDefault();
                var customerId = $(this).val();

                if (customerId) {
                    fetchPlots(customerId);
                } else {
                    // If no project is selected, empty the customer dropdown
                    $('#plot_id').empty();
                    $('#plot_id').append('<option value="">Select plots</option>');
                }

            });

            function fetchPlots(customerId) {
                $.ajax({
                    url: '/admin/get-plots-list', // URL to your route
                    type: 'POST', // Use POST method for sending data
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>', // Add CSRF token
                        project_id: '<?php echo e(getSelectedTown()); ?>',
                        customer_id: customerId // Pass project ID to server
                    },
                    success: function(data) {
                        // Populate customer dropdown with retrieved data
                        $('#plot_id').empty();
                        $('#plot_id').append('<option value="">Select Plots</option>');
                        $.each(data, function(key, plot) {
                            var plotType = (plot.type == 1) ? 'R- ' : 'C- ';
                            $('#plot_id').append('<option value="' + plot.plot_id + '">' + plotType + ' ' + plot.name +  '  </option>');
                        });
                    }
                });
            }

            $(document).on("click", '.btn-edit', function() {
                debugger;
                let id = $(this).attr("data-id");
                $('#modal-loading').modal({backdrop: 'static', keyboard: false, show: true});
                $.ajax({
                    url: "<?php echo e(route('ledger.show')); ?>",
                    type: "POST",
                    dataType: "JSON",
                    data: {
                        id: id,
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(data) {
                        debugger;
                        var data = data.data;
                        console.log('data in the database  = ',data);
                        $("#id").val(data.id);
                        $("#reference").val(data.reference);
                        $('#e_projects_id').val(data.project_head_subhead.project_id).trigger('change');
                        // $('#e_accounts_id').val(data.project_head_subhead.head_accounting_id).trigger('change');

                        // Set the default date in the date input field using flatpickr
                        flatpickr('#date', {
                            enableTime: false,
                            dateFormat: "Y-m-d",
                            defaultDate: data.date // Set the fetched date as the default date
                        });

                        $("#voucher").val(data.type+'-0000'+data.type_id);

                        if (data.type == 'CR') {
                            $("#amount").val(data.amount_in);

                        } else if(data.type == 'CP') {
                            $("#amount").val(data.amount_out);

                        }

                        $("#detail").val(data.detail);
                        console.log(data.detail);

                        $('#modal-loading').modal('hide');
                        $('#modal-edit').modal({backdrop: 'static', keyboard: false, show: true});
                    },
                });
            });

            $('#e_accounts_id').change(function () {
                var accountID = $(this).val();
                var projectID = <?php echo e(getSelectedTown()); ?>;


                if (accountID) {
                    // Implement AJAX call to fetch subheadaccounts based on the selected account
                    $.ajax({
                        url: '<?php echo e(route('get_account')); ?>', // Replace with your actual route
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            projectID: projectID,
                            accountID: accountID,
                            action: 'get_child',

                            _token: '<?php echo e(csrf_token()); ?>' // Include CSRF token for Laravel
                        },
                        success: function (data) {
                            $('#e_subaccounts_id').empty();
                            console.log(data);
                            // Filter data to match selected project ID
                            var filteredData = data.filter(function(item) {
                                return item.head_accounting_id  == accountID;
                            });
                            $('#e_subaccounts_id').append('<option value="">Select an option</option>');

                            // Append filtered head accounting options to 'Accounts' dropdown
                            $.each(filteredData, function(key, value) {
                                $('#e_subaccounts_id').append('<option value="' + value.subhead_accounting_id + '">' + value.subhead_accounting.name + '</option>');
                            });

                            // You may implement a similar AJAX call to fetch subheadaccounts based on the selected account
                        }
                    });
                } else {
                    $('#e_subaccounts_id').empty();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>


<div class="modal fade" id="modal-edit">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header ">
                <h4 class="modal-title">Update Cheque</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('report.check.bank.posting')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <div class="row">

                        <div class="col-sm-12">
                            <div class="row">

                                <div class="col-sm-3">
                                    <div class="input-group">
                                        <label class="fbox">Voucher No.</label>
                                        <div class="input-group">
                                            <input type="text" value="1" name="action" hidden />
                                            <input type="text"  class="form-control " name="voucher" value="<?php echo e('BR'); ?>-<?php echo e(get_new_voucher_number('BR')); ?>" autocomplete="off" readonly>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="customer">Status</label>
                                        <select class="form-control select2" name="passing_status" id="passing_status">
                                            <option value=""> All </option>
                                            <?php $__currentLoopData = check_status(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($v['id']); ?>" <?php echo e($old_passing_status == $v['id'] ? 'selected' : ''); ?>><?php echo e($v['name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['passing_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <label class="fbox">Passing Date</label>
                                        <div class="input-group">
                                            <input type="text" id="date" name="bank_post_at" class="date_database form-control" data-input>
                                            <!-- Add a hidden input to store the selected date in a format you want -->
                                            
                                            
                                            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="input-group">
                                <label class="fbox">Detail</label>
                                <div class="input-group">
                                    <textarea id="note" class="form-control <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Note" name="note" style=" height: 150px;" maxlength="255" ><?php echo e(old('note')); ?></textarea>
                                    <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="fbox">Head</label>
                                <select class="form-control " name="accounts_id" id="e_accounts_id">
                                    <option value=""> Passing Account  </option>
                                    <?php $__currentLoopData = $head_account_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $head_account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($head_account->head_accounting_id); ?>">
                                            <?php echo e($head_account->headAccounting->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['accounts_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="input-group">
                                <label class="fbox">Party Account</label>
                                <div class="input-group">
                                    <select class="form-control select2" name="subaccounts_id" id="e_subaccounts_id">
                                        <option value="">Select an option</option>
                                    </select>
                                    <?php $__errorArgs = ['subaccounts_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                    </div>




                    <div class="modal-footer justify-content-between">
                        <input type="hidden" name="id" id="id">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blueMarketing\resources\views/admin/reports/vouchers/check_report.blade.php ENDPATH**/ ?>