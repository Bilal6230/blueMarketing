<?php $__currentLoopData = $personWiseReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="labour-row" data-id="<?php echo e($report['id']); ?>" data-name="<?php echo e($report['name']); ?>"
        data-mobile="<?php echo e($report['mobile']); ?>" data-role="<?php echo e($report['designation']); ?>" data-rate="<?php echo e($report['rate']); ?>"
        data-advance="<?php echo e($report['advance']); ?>" data-attendance-dates="<?php echo e($report['attendance_dates']); ?>">
        <td class="labour-tooltip"
            data-tooltip="
Name: <?php echo e($report['name']); ?>

Father Name: <?php echo e($report['father_name']); ?>

CNIC: <?php echo e($report['cnic']); ?>

Phone: <?php echo e($report['mobile']); ?>

Role: <?php echo e($report['designation']); ?>

Daily Wage: Rs <?php echo e($report['rate']); ?>

">
            <?php echo e($report['name'] ?? ''); ?> (<?php echo e(substr($report['cnic'], -4)); ?>)</td>
        <td><?php echo e($report['mobile'] ?? ''); ?></td>
        <td><?php echo e($report['designation'] ?? ''); ?></td>
        <td>PKR <?php echo e($report['rate'] ?? ''); ?></td>
        <td><?php echo e($report['days']); ?></td>
        <td><?php echo e($report['overtime']); ?></td>
        
        <td>
            <div class="stars" style="--rating: <?php echo e($report['ratings']); ?>;"
                aria-label="Rating of <?php echo e($report['ratings']); ?> out of 5"></div>
        </td>
        <td><?php echo e($report['amount']); ?></td>
        <td><?php echo e($report['remaningAmount']); ?></td>
        
        
        <td><input type="number" class="form-control labour_amount" name="labour_amount[]"
                data-id="<?php echo e($report['id']); ?>">
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td colspan="8" style="text-align:right;">Total</td>
    <td><?php echo e($total_amount ?? ''); ?></td>
    <td>
        <?php if($personWiseReports->count() > 0): ?>
            <button class="btn ghost" id="createLabourVoucher">Create Labour Voucher</button>
        <?php endif; ?>
    </td>
</tr>
<?php /**PATH C:\laragon\www\blueMarketing\resources\views/admin/labours/person-wise-report.blade.php ENDPATH**/ ?>