
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper pt-4">
        <section class="content">
            <div class="container-fluid">
                <div class="custom_card h-100">
                    <div class="card-body">
                        <div class="mb-3 d-flex align-items-center justify-content-between">
                            <h3><?php echo e($title); ?></h3>
                            <button class="btn btn-sm custom_btn primary" data-toggle="modal" data-target="#addStockModal">
                                <i class="fas fa-plus mr-1"></i> Add Stock
                            </button>
                        </div>
                        <?php if($stocks->isNotEmpty()): ?>
                            <table class="table table-hover" id="stockTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Type</th>
                                        <th>Quantity</th>
                                        <th>Total Used</th>
                                        <th>Total Remaining</th>
                                        <th>Created At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($stock->id); ?></td>
                                            <td><?php echo e($stock->stock_name ?? 'N/A'); ?></td>
                                            <td>
                                                <span
                                                    class="badge <?php echo e($stock->type === 'purchase' ? 'badge-success' : 'badge-danger'); ?>"
                                                    style="min-width: 60px;">
                                                    <?php echo e(ucfirst($stock->type)); ?>

                                                </span>
                                            </td>
                                            <td><?php echo e($stock->quantity); ?></td>
                                            <td><?php echo e($stock->total_used); ?></td>
                                            <td><?php echo e($stock->total_remaining); ?></td>
                                            <td><?php echo e($stock->created_at->format('d M, Y')); ?></td>
                                            <td>
                                                <button class="btn btn-info btn-sm editBtn" data-id="<?php echo e($stock->id); ?>"
                                                    data-project="<?php echo e($stock->project_id); ?>"
                                                    data-type="<?php echo e($stock->type); ?>" data-quantity="<?php echo e($stock->quantity); ?>"
                                                    data-used="<?php echo e($stock->total_used); ?>"
                                                    data-remaining="<?php echo e($stock->total_remaining); ?>" data-toggle="modal"
                                                    data-target="#editStockModal">
                                                    <i class="fas fa-edit"></i>
                                                </button>

                                                <form id="delete-form-<?php echo e($stock->id); ?>"
                                                    action="<?php echo e(route('stocks.destroy', $stock)); ?>" method="POST"
                                                    style="display:inline-block">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="button" class="btn btn-danger btn-sm"
                                                        onclick="confirmDelete(<?php echo e($stock->id); ?>)">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="notfound bg-white p-3">
                                <div class="d-flex flex-wrap justify-content-center align-items-center">
                                    <div class="image-notfound mr-3">
                                        <img src="<?php echo e(asset('dist/images/not-found.png')); ?>" class="img-fluid">
                                    </div>
                                    <div class="text-notfound text-center">
                                        <h4 class="mb-0 f-20 text-dark"><?php echo e(__('Sorry! No data found.')); ?></h4>
                                        <p class="mb-0 f-16 text-gray-100 mt-2">
                                            <?php echo e(__('The requested data does not exist for this feature overview.')); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Add Modal -->
    <div class="modal fade" id="addStockModal" tabindex="-1" aria-labelledby="addStockModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg"> 
            <form action="<?php echo e(route('stocks.store')); ?>" method="POST" class="modal-content shadow-lg border-0 rounded-3">
                <?php echo csrf_field(); ?>
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="addStockModalLabel">
                        <i class="fas fa-plus-circle mr-2"></i> Add Stock
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-dismiss="modal" aria-label="Close"> <span
                            aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php echo $__env->make('admin.stocks.form', ['idPrefix' => 'add'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary px-4" data-dismiss="modal">
                        <i class="fas fa-times mr-1"></i> Close
                    </button>
                    <button type="submit" class="btn btn-success px-4">
                        <i class="fas fa-save mr-1"></i> Save
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="editStockModal" tabindex="-1" aria-labelledby="editStockModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg"> 
            <form method="POST" id="editStockForm" class="modal-content shadow-lg border-0 rounded-3">
                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title" id="editStockModalLabel">
                        <i class="fas fa-edit mr-2"></i> Edit Stock
                    </h5>
                    <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"> <span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <?php echo $__env->make('admin.stocks.form', ['idPrefix' => 'edit'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary px-4" data-dismiss="modal">
                        <i class="fas fa-times mr-1"></i> Close
                    </button>
                    <button type="submit" class="btn btn-success px-4">
                        <i class="fas fa-check mr-1"></i> Update
                    </button>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function() {
            $("#stockTable").DataTable({
                "responsive": true,
                "lengthChange": true,
                "autoWidth": false,
                "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            })

            function calculateRemaining(prefix) {
                let quantity = parseInt($('#' + prefix + '_quantity').val()) || 0;
                let used = parseInt($('#' + prefix + '_total_used').val()) || 0;
                $('#' + prefix + '_total_remaining').val(quantity - used);
            }

            $('#add_quantity, #add_total_used').on('input', function() {
                calculateRemaining('add');
            });

            $('#edit_quantity, #edit_total_used').on('input', function() {
                calculateRemaining('edit');
            });

            $(document).on('click', '.editBtn', function() {
                let id = $(this).data('id');
                let updateUrl = "<?php echo e(route('stocks.update', ':id')); ?>".replace(':id', id);
                $('#editStockForm').attr('action', updateUrl);

                $('#edit_quantity').val($(this).data('quantity'));
                $('#edit_total_used').val($(this).data('used'));
                $('#edit_total_remaining').val($(this).data('remaining'));
                $('#edit_type').val($(this).data('type'));

                calculateRemaining('edit'); // recalc when opening
            });

        });
    </script>
    <?php if($errors->any()): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    toast: true,
                    position: 'top-end', // top right
                    icon: 'error',
                    title: `<?php echo implode('<br>', $errors->all()); ?>`,
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true
                });
            });
        </script>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    toast: true,
                    position: 'top-end',
                    icon: 'success',
                    title: '<?php echo e(session('success')); ?>',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true
                });
            });
        </script>
    <?php endif; ?>
    <script>
        function confirmDelete(stockId) {
            Swal.fire({
                title: 'Are you sure?',
                text: "This stock will be permanently deleted!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('delete-form-' + stockId).submit();
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blueMarketing\resources\views/admin/stocks/index.blade.php ENDPATH**/ ?>