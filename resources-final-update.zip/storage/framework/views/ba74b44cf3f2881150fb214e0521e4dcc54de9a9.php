<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($title); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div>
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- Total Sale Amount Card -->
                    <div class="col-md-4">
                        <div class="card" style="background-color: #fd7e14; color: #fff; border-radius: 10px;">
                            <div class="card-body">
                                <h5 class="card-title">Total Sale Amount</h5>
                                <p class="card-text">
                                    <strong><?php echo e(Setting::formatAmount($totalSaleAmount)); ?></strong>
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Plots List Card -->
                    <div class="col-12">
                        <div class="card">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create plot')): ?>
                            <div class="card-header">
                                <h3 class="card-title">
                                    <a href="<?php echo e(route('booking.plot.sale')); ?>" class="btn btn-sm btn-success" ><i class="fas fa-plus"></i> New Booking</a>
                                </h3>
                            </div>
                            <?php endif; ?>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Date</th>
                                            <th>Broker</th>
                                            <th>Plot</th>
                                            <th>Customer</th>
                                            <th>Phone</th>
                                            <th>Sale Amount</th>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['update plot', 'delete plot'])): ?>
                                                <th>Action</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e(Setting::getShortDate($i->booking_date)); ?></td>
                                                <td><?php echo e($i->broker->name ?? ""); ?></td>
                                                
                                                
                                                <td>
                                                    <?php echo e(Setting::getPlotTypeShort($i->plot_type)); ?> - 
                                                    <form action="<?php echo e(route('booking.customer.report.display')); ?>" method="POST" style="display: inline;">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="plot_id" value="<?php echo e($i->plot->id); ?>">
                                                        <input type="hidden" name="customer_id" value="<?php echo e($i->customer->id); ?>">
                                                        <input type="hidden" name="action" value="booking_file">

                                                        <button type="submit" class="btn btn-card" style="padding: 10px 15px; border: 1px solid #ddd; border-radius: 5px; background: linear-gradient(135deg, #6c5ce7, #00b894); color: white; font-size: 14px; text-align: center; cursor: pointer; transition: transform 0.2s ease;">
                                                            <?php echo e($i->plot->name); ?>

                                                        </button>
                                                    </form>
                                                </td>
                                                
                                                <td><?php echo e($i->customer->first_name.' '.$i->customer->last_name.' '.$i->customer->relate.' '.$i->customer->father_name); ?></td>
                                                <td><?php echo e($i->customer->phone_number); ?></td>
                                                <td>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['update plot number', 'update booking price'])): ?>
                                                        <a href="<?php echo e(route('booking.price.update', ['id' => $i->id])); ?>" 
                                                           class="btn btn-link">
                                                            <?php echo e(Setting::formatAmount($i->total_price)); ?>

                                                        </a>
                                                    <?php else: ?>
                                                        <?php echo e(Setting::formatAmount($i->total_price)); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['update plot', 'delete plot', 'delete booking'])): ?>
                                                    <td>
                                                        <div class="btn-group">
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update plot')): ?>
                                                            <?php if(Setting::is_schedule($i->id) < 2): ?>
                                                            <a href="<?php echo e(route('booking.schedule.form', ['id' => $i->id])); ?>" 
                                                               class="btn btn-sm btn-primary btn-schedule" 
                                                               title="Schedule a Plot">
                                                                <i class="fas fa-plus"></i>
                                                            </a>
                                                            <?php else: ?>
                                                            <a href="<?php echo e(route('booking.schedule.form', ['id' => $i->id])); ?>" 
                                                               class="btn btn-sm btn-success btn-schedule" 
                                                               title="Edit Schedule">
                                                                <i class="fas fa-edit"></i>
                                                            </a>
                                                            <?php endif; ?>
                                                            <?php endif; ?>

                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete booking')): ?>
                                                            <!-- Delete Button -->
                                                            <button class="btn btn-sm btn-danger btn-delete-booking" 
                                                                    data-id="<?php echo e($i->id); ?>" 
                                                                    data-plot="<?php echo e($i->plot->name); ?>" 
                                                                    data-toggle="modal" 
                                                                    data-target="#deleteBookingModal">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                            <?php endif; ?>

                                                        </div>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function () {

        let plotName = ""; // Store correct plot name for validation

        // Open modal and set values
        $(".btn-delete-booking").click(function () {
            debugger;
            let bookingId = $(this).data("id");
            plotName = $(this).data("plot"); // Store correct plot name

            $("#booking_id").val(bookingId); // Set hidden booking_id
            $("#confirm_plot_number").val(""); // Clear input field
            $("#deleteError").hide(); // Hide error message
        });

        // Handle form submission for deletion
        $("#deleteBookingForm").submit(function (e) {
            e.preventDefault(); // Prevent default form submission

            let enteredPlotName = $("#confirm_plot_number").val().trim(); // Trim spaces

            if (enteredPlotName !== plotName) {
                $("#deleteError").show(); // Show error message
                return false;
            }

            let bookingId = $("#booking_id").val();
            let deleteUrl = "<?php echo e(route('booking.destroy', ':id')); ?>".replace(':id', bookingId);

            $.ajax({
                url: deleteUrl,
                type: "DELETE", // Use DELETE method
                data: {
                    _token: "<?php echo e(csrf_token()); ?>", // CSRF token for security
                    booking_id: bookingId
                },
                success: function (response) {
                    $("#deleteBookingModal").modal("hide"); // Close modal
                    location.reload(); // Reload page after deletion
                },
                error: function (xhr) {
                    alert("Error deleting booking. Please try again!"); // Show error message
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>
<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteBookingModal" tabindex="-1" role="dialog" aria-labelledby="deleteBookingModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteBookingModalLabel">Confirm Booking Deletion</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="deleteBookingForm" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <div class="modal-body">
                    <p>Please enter the **Plot Number** to confirm deletion:</p>
                    <input type="hidden" name="booking_id" id="booking_id">
                    <input type="text" class="form-control" id="confirm_plot_number" placeholder="Enter Plot Number">
                    <small class="text-danger" id="deleteError" style="display: none;">Incorrect plot number!</small>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Confirm Delete</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u541740294/domains/bluemarketing.com.pk/public_html/hr/resources/views/admin/booking/index.blade.php ENDPATH**/ ?>