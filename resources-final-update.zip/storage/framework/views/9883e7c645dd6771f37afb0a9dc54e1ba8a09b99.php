<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Dashboard</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                </ol>
            </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <!-- Small boxes (Stat box) -->
                <div class="row">
                    <div class="col-lg-4 col-6">
                        <!-- small box -->
                        <div class="small-box bg-info">
                        <div class="inner">
                            <h3><?php echo e($today_leads); ?></h3>
                            <p>New Leads Add Today</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-smile"></i>
                        </div>
                        <a href="<?php echo e(route('dashboard.leads_by_users_report')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-4 col-6">
                        <!-- small box -->
                        <div class="small-box bg-success">
                        <div class="inner">
                            <h3><?php echo e(Setting::getTodayLeadWorkCount()); ?></h3>
                            <p>Today Follow UP</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-comments"></i>
                        </div>
                        <a href="<?php echo e(route('crm.todayLeadWorkReport')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-4 col-6">
                        <!-- small box -->
                        <div class="small-box bg-warning">
                        <div class="inner">
                            <h3><?php echo e(count($permission)); ?></h3>

                            <p>Permission</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-unlock"></i>
                        </div>
                        <a href="<?php echo e(route('permission.index')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                </div>
                <!-- /.row (main row) -->

                
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['lead search', 'lead details','read attendance'])): ?>
                        
                        <div class="row">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lead search')): ?>
                                <div class="col-md-6">
                                    <div class="card card-info">
                                        <div class="card-header">
                                        <h3 class="card-title">Search Lead By Number</h3>
                                        </div>
                                        <!-- /.card-header -->
                                        <!-- form start -->
                                        <div class="card-body">
                                                <div class="form-group row">
                                                <div class="input-group input-group-sm">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="text" class="form-control" name="number" id="number" maxlength="11" size="11">
                                                        <span class="input-group-append">
                                                        <button type="submit" class="btn btn-info btn-flat" id="search_number">Go!</button>
                                                        </span>
                                                </div>
                                                </div>
                                                <div class="form-group row">
                                                    <div id="msg" class="message message-success col-lg-12 col-12" >

                                                    </div>

                                                </div>


                                            </div>

                                    </div>
                                        <!-- /.col -->
                                </div>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read attendance')): ?>
                                <div class="col-md-6">
                                    <div class="card card-danger">
                                        <div class="card-header">
                                        <h3 class="card-title">Employee Attendance</h3>
                                        </div>
                                        <!-- /.card-header -->
                                        <!-- form start -->
                                        <div class="card-body">
                                                <div class="form-group">
                                                <div class=" input-group-sm">
                                                    <form action="/admin/punch" method="POST" enctype="multipart/form-data">
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <?php echo csrf_field(); ?>
                                                                <select class="form-control"  name="user_id">
                                                                    <?php $__currentLoopData = $users_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($u->id); ?>"> <?php echo e($u->name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    


                                                                </select>
                                                            </div>

                                                            <?php if($display_date): ?>
                                                            
                                                            <div class="col-md-6">
                                                                <input type="datetime-local" class="form-control" name="punch_time" id="date_time">
                                                            </div>
                                                            <?php endif; ?>

                                                            
                                                        </div>
                                                        

                                                        <span class="input-group-append">
                                                        <button type="submit" class="btn btn-info btn-flat" id="punch_button">Punch</button>
                                                        </span>

                                                    </form>
                                                        
                                                </div>
                                                </div>
                                                <div class="form-group row">
                                                    <div id="msg" class="message message-success col-lg-12 col-12" >

                                                    </div>

                                                </div>


                                            </div>

                                    </div>
                                        <!-- /.col -->
                                </div>
                            <?php endif; ?>

                            
                        </div>
                        
                    <?php endif; ?> 

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read attendance'])): ?>
                        <div class="col-md-12">
                            <h4>Punch-in Records for Today</h4>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>User Name</th>
                                        <th>Punch In</th>
                                        <th>Punch Out</th>
                                        <th>Total Hours</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $today_punches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $punch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(date('Y-m-d', strtotime($punch->punch_in))); ?></td>
                                        <td><?php echo e($punch->user->name); ?></td>
                                        <td><?php echo e(date('H:i:s', strtotime($punch->punch_in))); ?></td>
                                        <td><?php echo e($punch->punch_out ? date('H:i:s', strtotime($punch->punch_out)) : 'N/A'); ?></td>

                                        <td>
                                            <?php if($punch->punch_out): ?>
                                                <?php
                                                    $punchInTime = strtotime($punch->punch_in);
                                                    $punchOutTime = strtotime($punch->punch_out);
                                                    $totalSeconds = $punchOutTime - $punchInTime;
                                                    $hours = floor($totalSeconds / 3600);
                                                    $minutes = floor(($totalSeconds % 3600) / 60);
                                                    $seconds = $totalSeconds % 60;
                                                ?>
                                                <?php echo e($hours); ?>h <?php echo e($minutes); ?>m <?php echo e($seconds); ?>s
                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </td>

                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>   

                        

                    
                  
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hr\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>