<div class="attn table" id="attnBoard">

    
    <div class="left" id="attnLabours">
        <div class="days-head" id="attnDays">
            <div class="d">Labours</div>
        </div>

        <?php $__currentLoopData = $attendance_labours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="lab labour-tooltip" data-id="<?php echo e($labour->id); ?>"
                data-tooltip="
Name: <?php echo e($labour['name']); ?>

Father Name: <?php echo e($labour['father_name']); ?>

CNIC: <?php echo e($labour['cnic']); ?>

Phone: <?php echo e($labour['phone']); ?>

Role: <?php echo e($labour['role']); ?>

Daily Wage: Rs <?php echo e($labour['daily_wage']); ?>

">

                <span class="nm"><?php echo e($labour->name); ?> (<?php echo e(substr($labour['cnic'], -4)); ?>)</span>
                <span class="muted small">
                    <?php echo e($labour->phone); ?> · <?php echo e($labour->role); ?> · Rs&nbsp;<?php echo e($labour->daily_wage); ?>

                </span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php
        use Carbon\Carbon;
        [$start, $end, $weekDays] = loadAttendanceWeek($week ?? now()->format('Y-m-d'));
    ?>


    
    <div class="right">

        
        <div class="days-head">
            <?php $__currentLoopData = $weekDays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $carbon = Carbon::parse($day);
                    $dayShort = strtoupper(substr($carbon->format('D'), 0, 1)); // F, S, S, M, T, W, T
                    $dateNum = $carbon->format('d');
                ?>

                <div class="d <?php echo e($day == now()->format('Y-m-d') ? 'today' : ''); ?>">
                    <div class="day-top"><?php echo e($dayShort); ?></div>
                    <div class="day-date"><?php echo e($dateNum); ?></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


        
        <div class="rows" id="attnRows">
            <?php $__currentLoopData = $attendance_labours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row-days">

                    <?php $__currentLoopData = $weekDays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $attendance = $labour->attendances->where('date', $day)->first();

                            $status = 'present';
                            $icon = '-';
                            $iconClass = 'none';

                            if ($attendance) {
                                if ($attendance->hours == 4) {
                                    $status = 'leave';
                                    $icon = 'H';
                                    $iconClass = 'leave';
                                } elseif ($attendance->status == 'present') {
                                    $status = 'present';
                                    $icon = '✓';
                                    $iconClass = 'tick';
                                } else {
                                    $status = 'absent';
                                    $icon = '✗';
                                    $iconClass = 'cross';
                                }
                            }

                            $userData = [
                                'id' => $labour->id,
                                'name' => $labour->name,
                                'role' => $labour->role,
                                'date' => $day,
                                'status' => $status,
                                'hours' => $attendance->hours ?? 8,
                                'ot' => $attendance->ot_hours ?? 0,
                                'site' => $attendance->site_id ?? null,
                                'rate' => $labour->daily_wage,
                                'amount' => $attendance->amount ?? $labour->daily_wage,
                            ];
                        ?>

                        <div class="cell" data-id="<?php echo e($labour->id); ?>" data-date="<?php echo e($day); ?>"
                            data-user='<?php echo json_encode($userData, 15, 512) ?>'>

                            <span class="ico <?php echo e($iconClass); ?>"><?php echo e($icon); ?></span>

                            <?php if($attendance && $attendance->ot_hours > 0): ?>
                                <span class="ico tick ot-badge"><?php echo e(number_format($attendance->ot_hours)); ?></span>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</div>
<?php /**PATH C:\laragon\www\blueMarketing\resources\views/admin/labours/attn-board.blade.php ENDPATH**/ ?>