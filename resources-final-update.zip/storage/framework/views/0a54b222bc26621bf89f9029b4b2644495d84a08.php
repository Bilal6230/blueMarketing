<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Dashboard</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                </ol>
            </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <!-- Small boxes (Stat box) -->
                <div class="row">
                    <div class="col-lg-4 col-6">
                        <!-- small box -->
                        <div class="small-box bg-info">
                        <div class="inner">
                            <h3><?php echo e(count($user)); ?></h3>
                            <p>User</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-user"></i>
                        </div>
                        <a href="<?php echo e(route('user.index')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-4 col-6">
                        <!-- small box -->
                        <div class="small-box bg-success">
                        <div class="inner">
                            <h3><?php echo e(count($role)); ?></h3>
                            <p>Role</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-user-cog"></i>
                        </div>
                        <a href="<?php echo e(route('role.index')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-4 col-6">
                        <!-- small box -->
                        <div class="small-box bg-warning">
                        <div class="inner">
                            <h3><?php echo e(count($permission)); ?></h3>

                            <p>Permission</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-unlock"></i>
                        </div>
                        <a href="<?php echo e(route('permission.index')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                </div>
                <!-- /.row (main row) -->

                
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['lead search', 'lead details'])): ?>

                    <div class="col-md-6">
                        <div class="card card-info">
                            <div class="card-header">
                              <h3 class="card-title">Search Lead By Number</h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                              <div class="card-body">
                                <div class="form-group row">
                                  <div class="input-group input-group-sm">
                                        <?php echo csrf_field(); ?>
                                        <input type="text" class="form-control" name="number" id="number" maxlength="11" size="11">
                                        <span class="input-group-append">
                                        <button type="submit" class="btn btn-info btn-flat" id="search_number">Go!</button>
                                        </span>
                                  </div>
                                </div>
                                <div class="form-group row">
                                    <div id="msg" class="message message-success col-lg-12 col-12" >

                                    </div>

                                </div>


                              </div>

                    </div>
                    <!-- /.col -->
                  </div>
                  <?php endif; ?>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\crm\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>