<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo e($title); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div><!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Customer Report  </h3>
                            </div><!-- /.card-header -->

                            <div class="card-body">
                                
                                <form method="POST" action="<?php echo e(route('booking.customer.report.display')); ?>">
                                    <?php echo csrf_field(); ?>
                                    
                                    <div class="row">
                                        <div class="col-md-12">

                                        </div>
                                    </div>
                                    <div class="row">
                                       
                                        
                                        

                                        
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="customer">Customer</label>
                                                <select class="form-control select2" name="customer_id" id="customer_id">
                                                    <option value="">Select Customer</option>
                                                </select>
                                                <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="customer">Plot</label>
                                                <select class="form-control select2" name="plot_id" id="plot_id">
                                                    <option value=""> < All Plot > </option>
                                                </select>
                                                <?php $__errorArgs = ['plot_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="action">Report Type</label>
                                                <select class="form-control select2" name="action" id="action">
                                                    <option value=""> Select Report </option>
                                                    <option value="booking_file"> Booking File </option>
                                                    
                                                    <option value="recovery_report_details"> Customer Recovery Report </option>
                                                    <option value="customer_ledger">Customer Ledger</option>

                                                </select>
                                                <?php $__errorArgs = ['action'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        

                                    </div>
                                    <hr>
                                    
                                    <button type="submit" class="btn btn-danger">View</button>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>
        
        
    </div><!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    // Define a JavaScript variable to hold installment options
    $(document).ready(function () {
        fetchCustomers('<?php echo e(getSelectedTown()); ?>');
        function fetchCustomers(projectId) {
            $.ajax({
                url: '/admin/get-customers-byplot', // URL to your route
                type: 'POST', // Use POST method for sending data
                data: {
                    _token: '<?php echo e(csrf_token()); ?>', // Add CSRF token
                    project_id: projectId // Pass project ID to server
                },
                success: function(data) {
                    // Populate customer dropdown with retrieved data
                    $('#customer_id').empty();
                    $('#customer_id').append('<option value="">Select customer</option>');
                    $.each(data, function(key, customer) {
                        $('#customer_id').append('<option value="' + customer.id + '">' + customer.first_name + ' ' + customer.last_name +' '+ customer.relate + ' '+ customer.father_name + ' - ' + customer.phone_number + '</option>');
                    });
                }
            });
        }

        $('#customer_id').change(function (e) { 
            e.preventDefault();
            var customerId = $(this).val();

            if (customerId) {
                fetchPlots(customerId);
            } else {
                // If no project is selected, empty the customer dropdown
                $('#plot_id').empty();
                $('#plot_id').append('<option value="">Select plots</option>');
            }
                
        });

        function fetchPlots(customerId) {
            $.ajax({
                url: '/admin/get-plots-list', // URL to your route
                type: 'POST', // Use POST method for sending data
                data: {
                    _token: '<?php echo e(csrf_token()); ?>', // Add CSRF token
                    project_id: '<?php echo e(getSelectedTown()); ?>',
                    customer_id: customerId // Pass project ID to server
                },
                success: function(data) {
                    // Populate customer dropdown with retrieved data
                    $('#plot_id').empty();
                    $('#plot_id').append('<option value="">Select Plots</option>');
                    $.each(data, function(key, plot) {
                        var plotType = (plot.type == 1) ? 'R- ' : 'C- ';
                        $('#plot_id').append('<option value="' + plot.plot_id + '">' + plotType + ' ' + plot.name +  '  </option>');
                    });
                }
            });
        }
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u541740294/domains/bluemarketing.com.pk/public_html/hr/resources/views/admin/reports/bookings/customer_report.blade.php ENDPATH**/ ?>