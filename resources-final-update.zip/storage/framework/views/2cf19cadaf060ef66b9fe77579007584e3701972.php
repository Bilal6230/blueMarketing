<div class="row">
    
    <div class="col-md-12 mb-3">
        <label for="<?php echo e($idPrefix); ?>_stock_name" class="form-label fw-bold">Stock Name</label>
        <input type="text" name="stock_name" id="<?php echo e($idPrefix); ?>_stock_name"
            class="form-control <?php $__errorArgs = ['stock_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e(old('stock_name', $stock->stock_name ?? '')); ?>" placeholder="Enter stock name" required>
        <?php $__errorArgs = ['stock_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="col-md-6 mb-3">
        <label for="<?php echo e($idPrefix); ?>_type" class="form-label fw-bold">Type</label>
        <select name="type" id="<?php echo e($idPrefix); ?>_type" class="form-control" required>
            <option value="">Select Type</option>
            <option value="purchase">Purchase</option>
            <option value="sale">Sale</option>
        </select>
    </div>

    
    <div class="col-md-6 mb-3">
        <label for="<?php echo e($idPrefix); ?>_quantity" class="form-label fw-bold">Quantity</label>
        <input type="number" name="quantity" id="<?php echo e($idPrefix); ?>_quantity"
            class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e(old('quantity', $stock->quantity ?? '')); ?>" placeholder="Enter quantity" required>
        <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="col-md-6 mb-3">
        <label for="<?php echo e($idPrefix); ?>_total_used" class="form-label fw-bold">Total Used</label>
        <input type="number" name="total_used" id="<?php echo e($idPrefix); ?>_total_used"
            class="form-control <?php $__errorArgs = ['total_used'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e(old('total_used', $stock->total_used ?? '')); ?>" placeholder="Enter total used" required>
        <?php $__errorArgs = ['total_used'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="col-md-6 mb-3">
        <label for="<?php echo e($idPrefix); ?>_total_remaining" class="form-label fw-bold">Total Remaining</label>
        <input type="number" name="total_remaining" id="<?php echo e($idPrefix); ?>_total_remaining" class="form-control"
            value="<?php echo e(old('total_remaining', $stock->total_remaining ?? '')); ?>" readonly>
    </div>
</div>
<?php /**PATH C:\laragon\www\blueMarketing\resources\views/admin/stocks/form.blade.php ENDPATH**/ ?>