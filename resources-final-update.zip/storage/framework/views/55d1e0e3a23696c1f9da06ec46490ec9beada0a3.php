<?php $__currentLoopData = $labours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr data-id="<?php echo e($labour->id); ?>" data-name="<?php echo e($labour->name); ?>"
        data-mobile="<?php echo e($labour->phone); ?>" data-role="<?php echo e($labour->role); ?>"
        data-rate="<?php echo e($labour->daily_wage); ?>" data-advance="0">
        <td><?php echo e($labour->name ?? ''); ?></td>
        <td><?php echo e($labour->phone ?? ''); ?></td>
        <td><?php echo e($labour->role ?? ''); ?></td>
        <td class="right">PKR <?php echo e($labour->daily_wage ?? ''); ?></td>
        <td class="right">PKR <?php echo e($labour->advance ?? ''); ?></td>
        <td><button class="btn editLabourBtn" data-id="<?php echo e($labour->id); ?>" labourData="<?php echo e(json_encode($labour)); ?>">Edit</button>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\blueMarketing\resources\views/admin/labours/labour.blade.php ENDPATH**/ ?>