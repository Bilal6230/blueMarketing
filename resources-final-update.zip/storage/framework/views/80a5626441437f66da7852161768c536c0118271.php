<?php $__env->startSection('content'); ?>
<style>
    /* Custom Styles */
    .no-records-card {
        background-color: #f8d7da;
        border-radius: 10px;
        padding: 20px;
        text-align: center;
        margin-top: 20px;
    }
</style>
<div class="container mt-5">
    <div class="card shadow-lg border-0">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0">Check History Report</h4>
            <a href="<?php echo e(route('report.check')); ?>" class="btn btn-success btn-sm">Back to Reports</a>
        </div>
        <div class="card-body">
            <!-- Check Number Displayed at the Top -->
            <div class="row mb-4">
                <div class="col-12 text-center">
                    <h3><strong>Check Number:</strong> <?php echo e($ledger->t_number); ?></h3>
                </div>
            </div>

            <!-- Customer & Plot Information -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <h5><strong>Customer:</strong> <?php echo e($ledger->customer_list->first_name); ?> <?php echo e($ledger->customer_list->last_name); ?></h5>
                    <h5><strong>Phone:</strong> <?php echo e($ledger->customer_list->phone_number); ?></h5>
                </div>
                <div class="col-md-6">
                    <h5><strong>Plot:</strong> <?php echo e(Setting::getPlotTypeShort($ledger->plot_list->type)); ?> - <?php echo e($ledger->plot_list->name); ?></h5>
                </div>
            </div>

            <!-- Check History Table or No Records Found Message -->
            <div class="table-responsive">
                <?php if(empty($checkHistory) || (is_array($checkHistory) && count($checkHistory) == 0) || ($checkHistory instanceof \Illuminate\Support\Collection && $checkHistory->isEmpty())): ?>
                <div class="no-records-card">
                        <h5>No records found.</h5>
                    </div>
                <?php else: ?>
                    <table class="table table-striped table-bordered">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th>#</th>
                                <th>Passing Date</th>
                                <th>Status</th>
                                <th>Description Note</th>
                                <th>Bank Name</th>
                                <th>Account</th>
                                <th>Last Updated</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $checkHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e(Setting::getShortDate($history['passing_date'])); ?></td>
                                
                                <td>
                                    <span class="badge <?php echo e(collect(check_status())->firstWhere('id', $history['passing_status'])['badge']); ?>" style="width: 80px">
                                        <?php echo e(collect(check_status())->firstWhere('id', $history['passing_status'])['name']); ?>

                                    </span>
                                </td>
                                <td><?php echo e($history['description_note']); ?></td>
                                <td><?php echo e($history['bank_name']); ?></td>
                                
                                <!-- Fetch Head Account and Sub Account Names using Credit Account ID -->
                                <td class="d-flex align-items-center">
                                    <div class="d-flex flex-column">
                                        <span class="font-weight-bold"><?php echo e(getHeadAccountNameById($history['credit_account_id'])); ?></span>
                                        <small class="text-muted"><?php echo e(getSubAccountNameById($history['credit_account_id'])); ?></small>
                                    </div>
                                </td>
                                
                                
                                <td><?php echo e(Setting::getShortDate($history['updated_at'])); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- Footer -->
        <div class="card-footer text-center bg-light">
            <button onclick="window.print()" class="btn btn-outline-primary">
                <i class="fas fa-print"></i> Print Report
            </button>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blueMarketing\resources\views/admin/reports/bookings/check_history.blade.php ENDPATH**/ ?>