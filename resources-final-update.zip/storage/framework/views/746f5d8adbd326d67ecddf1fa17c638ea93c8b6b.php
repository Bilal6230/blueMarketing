
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($title); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create lead')): ?>
                                <div class="card-header">
                                    <div>
                                        <?php
                                            $fromDate = old('fdate') ?: now()->subMonths(6)->format('d-m-Y');
                                            $toDate = old('tdate') ?: now()->format('d-m-Y');
                                        ?>




                                        <form action="<?php echo e(route('finance.reports.details_index')); ?>" method="POST"
                                            enctype="multipart/form-data" target="_blank">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-sm-2">
                                                    <div class="input-group">
                                                        <label class="fbox">From Date</label>
                                                        <div class="input-group">
                                                            <input type="text" name="fdate" class="date form-control"
                                                                data-input value="<?php echo e($fromDate); ?>">
                                                            <input type="hidden" id="hiddenFromDate" name="hiddenFromDate"
                                                                value="<?php echo e($fromDate); ?>">
                                                            <?php $__errorArgs = ['fdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-sm-2">
                                                    <div class="input-group">
                                                        <label class="fbox">To Date</label>
                                                        <div class="input-group">
                                                            <input type="text" name="tdate" class="date form-control"
                                                                data-input value="<?php echo e($toDate); ?>">
                                                            <input type="hidden" id="hiddenToDate" name="hiddenToDate"
                                                                value="<?php echo e($toDate); ?>">

                                                            <?php $__errorArgs = ['tdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-sm-4">
                                                    <div class="input-group">
                                                        <label class="fbox">Accounts</label>
                                                        <div class="input-group">
                                                            <select class="form-control select2" name="accounts_id"
                                                                id="accounts_id">
                                                                <option value="">Select Head</option>
                                                                <?php $__currentLoopData = $headaccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($head->id); ?>"
                                                                        <?php echo e(old('accounts_id') == $head->id ? 'selected' : ''); ?>>
                                                                        <?php echo e($head->name); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php $__errorArgs = ['accounts_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="input-group">
                                                        <label class="fbox">SubAccounts</label>
                                                        <div class="input-group">
                                                            <select class="form-control select2" name="subaccounts_id[]"
                                                                id="subaccounts_id" multiple>
                                                                <option value="">Select Sub Head</option>
                                                                <?php $__currentLoopData = $subheadaccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($sub->id); ?>"
                                                                        <?php echo e(collect(old('subaccounts_id'))->contains($sub->id) ? 'selected' : ''); ?>>
                                                                        <?php echo e($sub->name); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>

                                                            <?php $__errorArgs = ['subaccounts_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer justify-content-between">
                                                <button type="submit" class="btn btn-primary">Show</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php endif; ?>


                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {

            $('#projects_id').change(function() {
                var projectID = $(this).val();

                console.log(projectID);
                if (projectID) {
                    $.ajax({
                        url: '<?php echo e(route('get_account')); ?>', // Replace with your actual route
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            projectID: projectID,
                            action: 'get_head',
                            _token: '<?php echo e(csrf_token()); ?>' // Include CSRF token for Laravel
                        },
                        success: function(data) {
                            $('#accounts_id').empty();
                            $('#subaccounts_id').empty();
                            console.log(data);
                            // Filter data to match selected project ID
                            var filteredData = data.filter(function(item) {
                                return item.project_id == projectID;
                            });

                            // Append filtered head accounting options to 'Accounts' dropdown
                            $('#accounts_id').append(
                                '<option value="">Select an option</option>');
                            $.each(filteredData, function(key, value) {
                                $('#accounts_id').append('<option value="' + value
                                    .head_accounting_id + '">' + value
                                    .head_accounting.name + '</option>');
                            });

                            // You may implement a similar AJAX call to fetch subheadaccounts based on the selected account
                        }
                    });
                } else {
                    $('#accounts_id').empty();
                    $('#subaccounts_id').empty();
                }
            });

            // Similar change event for 'accounts_id' dropdown to fetch subaccounts based on account selection
            $('#accounts_id').change(function() {
                var accountID = $(this).val();
                var projectID = $('#projects_id').val();


                if (accountID) {
                    // Implement AJAX call to fetch subheadaccounts based on the selected account
                    $.ajax({
                        url: '<?php echo e(route('get_account')); ?>', // Replace with your actual route
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            projectID: projectID,
                            accountID: accountID,
                            action: 'get_child',

                            _token: '<?php echo e(csrf_token()); ?>' // Include CSRF token for Laravel
                        },
                        success: function(data) {
                            $('#subaccounts_id').empty();
                            console.log(data);
                            // Filter data to match selected project ID
                            var filteredData = data.filter(function(item) {
                                return item.head_accounting_id == accountID;
                            });
                            $('#subaccounts_id').append(
                                '<option value="">Select an option</option>');

                            // Append filtered head accounting options to 'Accounts' dropdown
                            $.each(filteredData, function(key, value) {
                                $('#subaccounts_id').append('<option value="' + value
                                    .subhead_accounting_id + '">' + value
                                    .subhead_accounting.name + '</option>');
                            });

                            // You may implement a similar AJAX call to fetch subheadaccounts based on the selected account
                        }
                    });
                } else {
                    $('#subaccounts_id').empty();
                }
            });

        });
    </script>
    <script>
        window.addEventListener("load", function() {
            const fInput = document.querySelector("input[name='fdate']"); // original input
            const hiddenFrom = document.getElementById('hiddenFromDate');

            // Use the value from hidden input if exists, otherwise 6 months ago
            const fromValue = hiddenFrom.value || new Date(new Date().setMonth(new Date().getMonth() - 6));

            flatpickr(fInput, {
                dateFormat: "d-m-Y",
                defaultDate: fromValue,
                allowInput: true,
                onChange: function(selectedDates, dateStr) {
                    hiddenFrom.value = dateStr || '';
                }
            });

            // TO DATE
            const tInput = document.querySelector("input[name='tdate']");
            const hiddenTo = document.getElementById('hiddenToDate');
            const toValue = hiddenTo.value || new Date();

            flatpickr(tInput, {
                dateFormat: "d-m-Y",
                defaultDate: toValue,
                allowInput: true,
                onChange: function(selectedDates, dateStr) {
                    hiddenTo.value = dateStr || '';
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blueMarketing\resources\views/admin/finance/reports/details_index.blade.php ENDPATH**/ ?>