<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-primary"><?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- Total Plots Overview -->
                <div class="col-md-3">
                    <div class="card text-center">
                        <div class="card-header bg-primary text-white">
                            <h3 class="card-title"><i class="fas fa-chart-pie"></i> Plots Overview</h3>
                        </div>
                        <div class="card-body">
                            <canvas id="plotsChart" style="max-height: 200px;"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Size Distribution -->
                <div class="col-md-3">
                    <div class="card text-center">
                        <div class="card-header bg-success text-white">
                            <h3 class="card-title"><i class="fas fa-ruler-combined"></i> Size Distribution</h3>
                        </div>
                        <div class="card-body">
                            <canvas id="sizeChart" style="max-height: 200px;"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Residential Plots -->
                <div class="col-md-3">
                    <div class="card text-center">
                        <div class="card-header bg-info text-white">
                            <h3 class="card-title"><i class="fas fa-home"></i> Residential Plots</h3>
                        </div>
                        <div class="card-body">
                            <canvas id="residentialChart" style="max-height: 200px;"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Shops Plots -->
                <div class="col-md-3">
                    <div class="card text-center">
                        <div class="card-header bg-danger text-white">
                            <h3 class="card-title"><i class="fas fa-store"></i> Shops</h3>
                        </div>
                        <div class="card-body">
                            <canvas id="shopsChart" style="max-height: 200px;"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-3">
                <!-- Sold Shops -->
                <div class="col-6">
                     <div class="p-2 bg-danger text-white">
                         <h4 class="m-0"><i class="fas fa-store"></i> Sold Shops</h4>
                     </div>
                     <div class="plot-list p-2 border">
                         <?php $__currentLoopData = $soldShops->chunk(15); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <p>
                                 <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php echo e($plot->name); ?> &nbsp; | &nbsp;
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </p>
                             <hr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>
                 </div>
 
                 <!-- Unsold Shops -->
                 <div class="col-6">
                     <div class="p-2 bg-secondary text-white">
                         <h4 class="m-0"><i class="fas fa-store"></i> Unsold Shops</h4>
                     </div>
                     <div class="plot-list p-2 border">
                         <?php $__currentLoopData = $unsoldShops->chunk(15); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <p>
                                 <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php echo e($plot->name); ?> &nbsp; | &nbsp;
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </p>
                             <hr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>
                 </div>
             </div>

            <div class="row mt-3">
                <!-- Sold Residential Plots -->
                <div class="col-6">
                    <div class="p-2 bg-info text-white">
                        <h4 class="m-0"><i class="fas fa-home"></i> Sold Residential Plots</h4>
                    </div>
                    <div class="plot-list p-2 border">
                        <?php $__currentLoopData = $soldResidential->chunk(15); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p>
                                <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($plot->name); ?> &nbsp; | &nbsp;
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <!-- Unsold Residential Plots -->

                <div class="col-6">
                    <div class="p-2 bg-warning text-white">
                        <h4 class="m-0"><i class="fas fa-home"></i> Unsold Residential Plots</h4>
                    </div>
                    <div class="plot-list p-2 border">
                        <?php $__currentLoopData = $unsoldResidential->chunk(15); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p>
                                <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($plot->name); ?> &nbsp; | &nbsp;
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>


                
            </div>


        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    function createPieChart(canvasId, labels, data, colors) {
        new Chart(document.getElementById(canvasId), {
            type: 'pie',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: colors
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }

    // Chart Data
    createPieChart('plotsChart', ['Total', 'Sold', 'Unsold'], 
        [<?php echo e($chartData['total']); ?>, <?php echo e($chartData['sold']); ?>, <?php echo e($chartData['unsold']); ?>], 
        ['#007bff', '#28a745', '#dc3545']);

    createPieChart('sizeChart', ['Sold Size', 'Unsold Size'], 
        [<?php echo e($sizeChartData['soldSize']); ?>, <?php echo e($sizeChartData['unsoldSize']); ?>], 
        ['#28a745', '#dc3545']);

    createPieChart('residentialChart', ['Sold', 'Unsold'], 
        [<?php echo e($residentialChartData['sold']); ?>, <?php echo e($residentialChartData['unsold']); ?>], 
        ['#28a745', '#dc3545']);

    createPieChart('shopsChart', ['Sold', 'Unsold'], 
        [<?php echo e($shopsChartData['sold']); ?>, <?php echo e($shopsChartData['unsold']); ?>], 
        ['#28a745', '#dc3545']);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u541740294/domains/bluemarketing.com.pk/public_html/hr/resources/views/admin/plots/inventory.blade.php ENDPATH**/ ?>