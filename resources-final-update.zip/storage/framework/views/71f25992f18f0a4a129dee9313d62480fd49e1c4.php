<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo e($title); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div><!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Booking Form </h3>
                            </div><!-- /.card-header -->

                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <!-- Display customer details here -->
                                        <p><strong>Name:</strong> <?php echo e($data->customer->first_name); ?> <?php echo e($data->customer->last_name); ?> <?php echo e($data->customer->relate); ?>  <?php echo e($data->customer->father_name); ?></p>
                                        <p><strong>Phone:</strong> <?php echo e($data->customer->phone_number); ?></p>
                                        <p><strong>CNIC:</strong> <?php echo e($data->customer->cnic); ?></p>
                                        <p><strong>Plot Number:</strong> <?php echo e($data->plot->name); ?></p>
                                        <p><strong>Sale Rate:</strong> <?php echo e($data->plot_rate); ?></p>
                                        <!-- Add more customer details here -->
                                    </div>
                                    <div class="col-md-6">
                                        <!-- Display customer details here -->
                                        <p><strong>CNIC:</strong> <?php echo e($data->customer->nic_number); ?></p>
                                        <p><strong>Mobile:</strong> <?php echo e($data->customer->mobile_number); ?></p>
                                        <p><strong>Address:</strong> <?php echo e($data->customer->office_address); ?></p>
                                        <p><strong>Plot Size:</strong> <?php echo e($data->plot_size); ?></p>
                                        <p><strong>Total Amount:</strong> <?php echo e($data->total_price); ?></p>
                                        <!-- Add more customer details here -->
                                    </div>

                                    

                                </div>
                                
                                
                                <form method="POST" action="<?php echo e(route('payment_schedule.store')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" name='booking_id' value="<?php echo e($data->id); ?>" hidden required>
                                    <input type="text" name='total_price' value="<?php echo e($data->total_price); ?>" hidden>
                                    <div class="row">
                                        <div class="col-md-12">

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="instalment">Total Instalment</label>
                                                <input type="number" class="form-control" id="instalment" name="instalment" placeholder="Total Number of instalment" required>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="payment_plan">Plan</label>
                                                <select class="form-control select2" name="payment_plan" id="payment_plan">
                                                    <option value="1">Monthly</option>
                                                    <option value="3">Quarterly</option>
                                                    <option value="6">Semi-annually</option>
                                                    <option value="12">Annually</option>

                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="start_date">Start Date</label>
                                                <div class="input-group">
                                                    <input type="text" name="start_date" class="date form-control" data-input>
                                                    <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <hr>
                                    <table id="payment_schedule_table">
                                        <thead>
                                            <tr>
                                                <th>Installment</th>
                                                <th>Amount</th>
                                                <th>Due Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <select class="form-control select2" name="installment_number[]" required>
                                                        <?php $__currentLoopData = getInstallmentOptions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td><input type="number" name="amount[]" step="0.01" required class="form-control"></td>
                                                <td><input type="date" name="due_date[]" required class="date form-control" data-input></td>
                                                <td><button type="button" class="btn btn-danger remove-row">Remove</button></td>

                                            </tr>
                                        </tbody>
                                    </table>
                                    <button type="button" onclick="addRow()" class="btn btn-danger">Add Row</button>
                                    <button type="submit" class="btn btn-danger">Save</button>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>
        
        
    </div><!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    // Define a JavaScript variable to hold installment options
    var installmentOptions = [
        <?php $__currentLoopData = getInstallmentOptions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            { value: '<?php echo e($key); ?>', text: '<?php echo e($value); ?>' },
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ];

    function addRow() {
        var table = document.getElementById("payment_schedule_table");
        var newRow = table.insertRow();

        var cell1 = newRow.insertCell(0);
        var cell2 = newRow.insertCell(1);
        var cell3 = newRow.insertCell(2);
        var cell4 = newRow.insertCell(3);

        // Populate installment number dropdown
        var selectHTML = '<select class="form-control select2" name="installment_number[]" required>';
            for (var i = 0; i < installmentOptions.length; i++) {
            selectHTML += '<option value="' + installmentOptions[i].value + '">' + installmentOptions[i].text + '</option>';
        }
        
        selectHTML += '</select>';
        cell1.innerHTML = selectHTML;

        // Other cells remain the same
        cell2.innerHTML = '<input type="number" name="amount[]" step="0.01" required class="form-control">';
        cell3.innerHTML = '<input type="date" name="due_date[]" required class="date form-control" data-input >';
        cell4.innerHTML = '<td><button type="button" class="btn btn-danger remove-row">Remove</button></td>';
    }

    // Remove row
    $(document).on('click', '.remove-row', function() {
            $(this).closest('tr').remove();
        });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blueMarketing\resources\views/admin/booking/schedule_form.blade.php ENDPATH**/ ?>