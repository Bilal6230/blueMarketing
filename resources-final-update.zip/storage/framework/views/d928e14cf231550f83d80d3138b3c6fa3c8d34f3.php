<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($title); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">

                <!-- Summary Cards -->
                <div class="row mb-4">
                    <!-- Card 1 -->
                    <div class="col-md-4">
                        <div class="card shadow" style="background-color: #fd7e14; color: #fff; border-radius: 10px;">
                            <div class="card-body text-center">
                                <h5 style="font-weight: bold;">Total Due Amount (<?php echo e(\Carbon\Carbon::today()->format('d M Y')); ?>)</h5>
                                <p class="h4"><?php echo e(Setting::roundformatAmount($sum_due_amount)); ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Card 2 -->
                    <div class="col-md-4">
                        <div class="card shadow" style="background-color: #4caf50; color: #fff; border-radius: 10px;">
                            <div class="card-body text-center">
                                <h5 style="font-weight: bold;">Total Received</h5>
                                <p class="h4"><?php echo e(Setting::roundformatAmount($sum_received)); ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Card 3 -->
                    <div class="col-md-4">
                        <div class="card shadow" style="background-color: #2196f3; color: #fff; border-radius: 10px;">
                            <div class="card-body text-center">
                                <h5 style="font-weight: bold;">Balance</h5>
                                <p class="h4"><?php echo e(Setting::roundformatAmount($sum_due_amount - $sum_received)); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Table -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><?php echo e($title); ?></h3>
                            </div>

                            <!-- Table Content -->
                            <div class="card-body table-responsive">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Date</th>
                                            <th>Broker</th>
                                            <th>Plot</th>
                                            <th>Customer</th>
                                            <th>Phone</th>
                                            <th>Due Amount</th>
                                            <th>Received</th>
                                            <th>Balance</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e(Setting::getShortDate($i->booking_date)); ?></td>
                                                <td><?php echo e($i->broker->name ?? ""); ?></td>
                                                <td><?php echo e(Setting::getPlotTypeShort($i->plot_type)); ?> - <a href="#"><?php echo e($i->plot->name ?? 'N/A'); ?></a></td>
                                                <td><?php echo e($i->customer->first_name ?? 'N/A'); ?> <?php echo e($i->customer->last_name ?? ''); ?></td>
                                                <td><?php echo e($i->customer->phone_number ?? 'N/A'); ?></td>
                                                <td><?php echo e(Setting::roundformatAmount(getSumDueAmount($i->id))); ?></td>
                                                <td><?php echo e(Setting::roundformatAmount(getSumRecovery($i->plot_id, 'amount_out'))); ?></td>
                                                <td><?php echo e(Setting::roundformatAmount(getSumDueAmount($i->id) - getSumRecovery($i->plot_id, 'amount_out'))); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $(document).on("click", '.btn-edit', function() {
                let id = $(this).attr("data-id");
                // Your edit logic here
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <!-- Add your modals here if needed -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u541740294/domains/bluemarketing.com.pk/public_html/hr/resources/views/admin/reports/bookings/project_recovery.blade.php ENDPATH**/ ?>