
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo e($title." - ".Setting::getValue('app_name')); ?></title>
        <link rel="icon" href="<?php echo e(asset(Setting::getValue('app_favicon'))); ?>" type="image/png" />
        <!-- Google Font: Source Sans Pro -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="<?php echo e(asset('template/admin/plugins/fontawesome-free/css/all.min.css')); ?>">
        <!-- daterange picker -->
        <link rel="stylesheet" href="<?php echo e(asset('template/admin/plugins/daterangepicker/daterangepicker.css')); ?>">
        <!-- Ionicons -->
        <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
        <!-- Theme style -->
        <link rel="stylesheet" href="<?php echo e(asset('template/admin/dist/css/adminlte.min.css')); ?>">
        <!-- iCheck for checkboxes and radio inputs -->
        <link rel="stylesheet" href="<?php echo e(asset('template/admin/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
        <!-- Bootstrap Color Picker -->
        <link rel="stylesheet" href="<?php echo e(asset('template/admin/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')); ?>">

        <!-- overlayScrollbars -->
        <link rel="stylesheet" href="<?php echo e(asset('template/admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
        <!-- DataTables -->
        <link rel="stylesheet" href="<?php echo e(asset('template/admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('template/admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('template/admin/plugins/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">

        <!-- Bootstrap Color Picker -->
        <link rel="stylesheet" href="<?php echo e(asset('template/admin/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')); ?>">

        <!-- Select2 -->
        <link rel="stylesheet" href="<?php echo e(asset('template/admin/plugins/select2/css/select2.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('template/admin/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

        <!-- Bootstrap4 Duallistbox -->
        <link rel="stylesheet" href="<?php echo e(asset('template/admin/plugins/bootstrap4-duallistbox/bootstrap-duallistbox.min.css')); ?>">
        <!-- BS Stepper -->
        <link rel="stylesheet" href="<?php echo e(asset('template/admin/plugins/bs-stepper/css/bs-stepper.min.css')); ?>">
        <!-- dropzonejs -->
        <link rel="stylesheet" href="<?php echo e(asset('template/admin/plugins/dropzone/min/dropzone.min.css')); ?>">


        <!-- Custom style -->
        <link rel="stylesheet" href="<?php echo e(asset('template/admin/dist/css/custom.css')); ?>">
        <?php echo $__env->yieldPushContent('style'); ?>
    </head>
    <body class="control-sidebar-slide-open  sidebar-mini">
        <?php
            if (!$errors->isEmpty()) {
                alert()->error('Pemberitahuan', implode('<br>', $errors->all()))->toToast()->toHtml();
            }
        ?>
        <div class="wrapper">
            <!-- Preloader -->
            <div class="preloader flex-column justify-content-center align-items-center">
                <img class="animation__shake" src="<?php echo e(asset(Setting::getValue('app_logo'))); ?>" alt="<?php echo e(Setting::getName('app_name')); ?>" height="60" width="60">
            </div>

            <!-- Navbar -->
            <?php echo $__env->make('admin.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- /.navbar -->

            <!-- Main Sidebar Container -->
            <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Content Wrapper. Contains page content -->
            <?php echo $__env->yieldContent('content'); ?>
            <!-- /.content-wrapper -->
            <?php echo $__env->yieldContent('modal'); ?>
            <?php echo $__env->make('admin.layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- ./wrapper -->
        <!-- jQuery -->
        <script src="<?php echo e(asset('template/admin/plugins/jquery/jquery.min.js')); ?>"></script>
        <?php echo $__env->yieldContent('js'); ?>
        <?php echo $__env->make('admin.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- jQuery UI 1.11.4 -->
        <script src="<?php echo e(asset('template/admin/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
        <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
        <!-- DataTables  & Plugins -->
        <script src="<?php echo e(asset('template/admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('template/admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>

        <script src="<?php echo e(asset('template/admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(asset('template/admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('template/admin/plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>

        <script src="<?php echo e(asset('template/admin/plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
        <script src="<?php echo e(asset('template/admin/plugins/jszip/jszip.min.js')); ?>"></script>
        <script src="<?php echo e(asset('template/admin/plugins/pdfmake/pdfmake.min.js')); ?>"></script>
        <script src="<?php echo e(asset('template/admin/plugins/pdfmake/vfs_fonts.js')); ?>"></script>
        <script src="<?php echo e(asset('template/admin/plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('template/admin/plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
        <script src="<?php echo e(asset('template/admin/plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>

        <!-- jQuery Mapael -->
        <script src="<?php echo e(asset('template/admin/plugins/jquery-mousewheel/jquery.mousewheel.js')); ?>"></script>
        <script src="<?php echo e(asset('template/admin/plugins/raphael/raphael.min.js')); ?>"></script>
        <script src="<?php echo e(asset('template/admin/plugins/jquery-mapael/jquery.mapael.min.js')); ?>"></script>
        <script src="<?php echo e(asset('template/admin/plugin/jquery-mapael/maps/usa_states.min.js')); ?>"></script>

        <!-- Select2 -->
        <script src="<?php echo e(asset('template/admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
        <!-- Bootstrap4 Duallistbox -->
        <script src="<?php echo e(asset('template/admin/plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js')); ?>"></script>
        <!-- InputMask -->
        <script src="<?php echo e(asset('template/admin/plugins/moment/moment.min.js')); ?>"></script>
        <script src="<?php echo e(asset('template/admin/plugins/inputmask/jquery.inputmask.min.js')); ?>"></script>

        <!-- date-range-picker -->
        <script src="<?php echo e(asset('template/admin/plugins/daterangepicker/daterangepicker.js')); ?>"></script>

        <!-- bootstrap color picker -->
        <script src="<?php echo e(asset('template/admin/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')); ?>"></script>
        <!-- Tempusdominus Bootstrap 4 -->
        <script src="<?php echo e(asset('template/admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
        <!-- BS-Stepper -->
        <script src="<?php echo e(asset('template/admin/plugins/bs-stepper/js/bs-stepper.min.js')); ?>"></script>

        <!-- dropzonejs -->
        <script src="<?php echo e(asset('template/admin/plugins/dropzone/min/dropzone.min.js')); ?>"></script>



        <!-- ChartJS -->
        <script src="<?php echo e(asset('template/admin/plugins/chart.js/Chart.min.js')); ?>"></script>
        <script>
            $.widget.bridge('uibutton', $.ui.button)
        </script>


        <!-- Bootstrap 4 -->
        <script src="<?php echo e(asset('template/admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <!-- overlayScrollbars -->
        <script src="<?php echo e(asset('template/admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
        <!-- AdminLTE App -->
        <script src="<?php echo e(asset('template/admin/dist/js/adminlte.js')); ?>"></script>

        <!-- AdminLTE for demo purposes -->
        
        <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
        <script src="<?php echo e(asset('template/admin/dist/js/pages/dashboard2.js')); ?>"></script>

            <!-- Page specific script -->
        <script>
            $(function () {
            $("#example1").DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');

            });


            $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date picker
    $('#reservationdate').datetimepicker({
        format: 'L'
    });

    //Date and time picker
    $('#reservationdatetime').datetimepicker({ icons: { time: 'far fa-clock' } });

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({
      timePicker: true,
      timePickerIncrement: 30,
      locale: {
        format: 'MM/DD/YYYY hh:mm A'
      }
    })
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Timepicker
    $('#timepicker').datetimepicker({
      format: 'LT'
    })

    //Bootstrap Duallistbox
    $('.duallistbox').bootstrapDualListbox()

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    $('.my-colorpicker2').on('colorpickerChange', function(event) {
      $('.my-colorpicker2 .fa-square').css('color', event.color.toString());
    })
  })
        </script>
        <?php echo $__env->yieldPushContent('script'); ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\laravelcms\resources\views/admin/layouts/master.blade.php ENDPATH**/ ?>