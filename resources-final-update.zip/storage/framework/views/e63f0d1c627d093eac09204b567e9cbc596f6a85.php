<?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr data-id="" data-name="<?php echo e($report['name']); ?>"
        data-mobile="<?php echo e($report['mobile']); ?>" data-role="<?php echo e($report['designation']); ?>"
        data-rate="<?php echo e($report['rate']); ?>" data-advance="0">
        <td  class="labour-tooltip"
        data-tooltip="
Name: <?php echo e($report['name']); ?>

Father Name: <?php echo e($report['father_name']); ?>

CNIC: <?php echo e($report['cnic']); ?>

Phone: <?php echo e($report['mobile']); ?>

Role: <?php echo e($report['designation']); ?>

Daily Wage: Rs <?php echo e($report['rate']); ?>

"><?php echo e($report['name'] ?? ''); ?> (<?php echo e(substr($report['cnic'], -4)); ?>)</td>
        <td><?php echo e($report['mobile'] ?? ''); ?></td>
        <td><?php echo e($report['designation'] ?? ''); ?></td>
        <td class="right">PKR <?php echo e($report['rate'] ?? ''); ?></td>
        <td class="right"><?php echo e($report['days']); ?></td>
        <td class="right"><?php echo e($report['overtime']); ?></td>
        <td class="right"><?php echo e($report['amount']); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\blueMarketing\resources\views/admin/labours/site-report.blade.php ENDPATH**/ ?>